<?php
include_once 'classes/site_config.php';
include_once 'classes/contribute.php';

if (isset($_POST['btn_submit'])) {
    if (!empty($_POST['price']) || !empty($_POST['other_price'])) {
        $data['price'] =  (isset($_POST['other_price']) && !empty($_POST['other_price'])) ? $_POST['other_price'] : $_POST['price'];

        $last_insert_id = save_contribute($data);
        $amt = get_details($last_insert_id);
        $amount = $amt['price'];

        if (isset($last_insert_id) && !empty($last_insert_id)) {
            require_once('classes/paypal.class.php');
            $p = new paypal_class;
            // $p->paypal_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr';   // testing paypal url
            $this_script =  SITEURL; //localhost Website url
            $p->paypal_url = 'https://www.paypal.com/cgi-bin/webscr'; // Live paypal url
            $p->add_field('rm', '2');   // return with post variables values
            // $p->add_field('business', 'sb-gg4de26080765@business.example.com');   //Test Business ID
            $p->add_field('business', 'mwavcorp2300@gmail.com');   //Live Business ID
            $p->add_field('at', "ACb9vut99j8KU2G14U9TkFjpZcjWAnDYW.r7Ou2lTSzmryt-ug8aG8G0");
            $p->add_field('return', $this_script . 'success.php');
            $p->add_field('cancel_return', $this_script . 'cancel.php');
            $p->add_field('item_name', 'Minority');
            $p->add_field('item_number', $last_insert_id);
            $p->add_field('currency_code', 'USD');
            $p->add_field('amount', $amount);
            $p->submit_paypal_post();
        }
    } else {
        echo '<script>alert("Please Input Price"); window.location="donate-now.php";</script>';
    }
}

