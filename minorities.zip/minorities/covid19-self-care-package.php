<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minorities With A Voice</title>
  <meta name="description" content="#">
  <meta name="keywords" content="#">

  <?php include("includes/header-files.php"); ?>
</head>

<body>

  <!-- ======End Preloader ======  -->

  <?php include("includes/header.php"); ?>

  <!-- Benner start -->
  <div class="common-banner-area">
    <div class="overlay"></div>
    <div class="container">
      <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">COVID19 Self Care Package</h1>
      </div>
    </div>
  </div>

  <!-- Benner end -->

  <!-- Start volunteers -->
  <section id="team" class="bg-silver-light">
    <div class="container">
      <div class="section-content">
        <div class="row multi-row-clearfix wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s">
          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/vitaminc.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Immune System Booster</p>
                    <p class="text-center">2,000 mg - 3,000 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">VITAMAN C</h3>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/turmeric.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Fights Inflammation</p>
                    <p class="text-center">500 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">TURMERIC</h3>
              </div>
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/echina.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Immune System Booster</p>
                    <p class="text-center">1,000 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">ECHINA CEA</h3>
              </div>
            </div>
          </div>

          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/apple.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Total Wellness</p>
                    <p class="text-center">450 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">APPLE CIDER VINEGAR PILLS</h3>
              </div>
            </div>
          </div>

          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/olive.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Antioxidant Immune Health</p>
                    <p class="text-center">150 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">OLIVE LEAF</h3>
              </div>
            </div>
          </div>

          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/berry.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Antioxidant Immune Booster</p>
                    <p class="text-center">200 mg - 1,000 mg per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">ELDERBERRY</h3>
              </div>
            </div>
          </div>

          <div class="col-xs-12 col-sm-6 col-md-4 mb-4">
            <div class="team-member clearfix">
              <div class="team-thumb">
                <img alt="" src="<?php echo SITEURL; ?>images/moringa.jpg" class="img-fullwidth">
                <div class="overlay">
                  <div class="content">
                    <p class="text-center">Total Wellness</p>
                    <p class="text-center">1 - 2 cups per day.</p>
                  </div>
                </div>
              </div>
              <div class="team-info bg-theme-colored">
                <h3 class="mt-0 mb-0 text-white">MORINGA TEA</h3>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>

  <!-- end volunteers -->

  <?php include("includes/footer.php"); ?>
</body>

</html>