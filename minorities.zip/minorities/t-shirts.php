<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minorities With A Voice</title>
  <meta name="description" content="#">
  <meta name="keywords" content="#">

  <?php include("includes/header-files.php"); ?>
</head>

<body>
  <?php include("includes/header.php"); ?>

  <!-- Benner start -->

  <div class="common-banner-area">
    <div class="overlay"></div>
    <div class="container">
      <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">T-Shirts</h1>
      </div>
    </div>
  </div>

  <!-- Banner end -->

  <!-- Start Causes
    ============================================= -->
  <section class="Causes-area">
    <div class="container">
      <div class="row wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s">
        <h4 class="text-center">Each shirt purchased feeds 3 people who are homeless, underprivileged or less fortunate. One purchase could feed an entire family. Please show your support and help fight hunger.</h4>
        <div class="col-md-4 mb-4">
          <div class="item">
            <div class="thumb figure">
              <a href="#">
                <img class="Sirv image-main" src="<?php echo SITEURL; ?>images/t-shirt-front.jpg" data-src="images/t-shirt-front.jpg">
                <img class="Sirv image-hover" src="<?php echo SITEURL; ?>images/t-shirt-front.jpg" data-src="images/t-shirt-back.jpg">
              </a>
            </div>
            <div class="info">
              <h4 class="mb-2">T-Shirt <span>$ 20.00</span></h4>
              <form action="checkout.php" method="post">
                <label for="XS 2yrs-4yrs"> XS 2yrs-4yrs</label>
                <input type="radio" name="size" value="XS"><br>
                <label for="Small 6yrs-8yrs"> Small 6yrs-8yrs</label>
                <input type="radio" name="size" value="Small"><br>
                <label for="Medium 10yrs-12yrs"> Medium 10yrs-12yrs</label>
                <input type="radio" name="size" value="Medium"><br>
                <label for="Large 14yrs-16yrs"> Large 14yrs-16yrs</label>
                <input type="radio" name="size" value="Large">
                <input type="hidden" name="price" value="20">
                <button class="btn btn-theme effect btn-sm" type="submit" name="btn_submit">Buy Now</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-4 mb-4">
          <div class="item">
            <div class="thumb figure">
              <a href="#">
                <img class="Sirv image-main" src="<?php echo SITEURL; ?>images/t-shirt-front.jpg" data-src="images/t-shirt-front.jpg">
                <img class="Sirv image-hover" src="<?php echo SITEURL; ?>images/t-shirt-front.jpg" data-src="images/t-shirt-back.jpg">
              </a>
            </div>
            <div class="info">
              <h4 class="mb-2">T-Shirt <span>$ 23.00</span></h4>
              <form action="checkout.php" method="post">
                <label for="small"> Small </label>
                <input type="radio" id="small" name="size" value="Small">
                <label for="medium"> Medium </label>
                <input type="radio" id="medium" name="size" value="Medium">
                <label for="large"> Large </label>
                <input type="radio" id="large" name="size" value="Large">
                <label for="x-large"> X-Large </label>
                <input type="radio" id="x-large" name="size" value="X-Large">
                <label for="2x-large"> 2X-Large </label>
                <input type="radio" id="2x-large" name="size" value="2X-Large">
                <label for="3x-large"> 3X-Large</label>
                <input type="radio" id="3x-large" name="size" value="3X-Large">
                <label for="4x-large"> 4X-Large</label>
                <input type="radio" id="4x-large" name="size" value="4X-Large">
                <label for="4x-large"> 5X-Large </label>
                <input type="radio" id="4x-large" name="size" value="5X-Large">
                <input type="hidden" name="price" value="23">
                <button class="btn btn-theme effect btn-sm" type="submit" name="btn_submit">Buy Now</button>
              </form>
              <!--<a class="" href="checkout.php">Buy Now</a>-->
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>
  <!-- End Causes -->

  <script src="https://scripts.sirv.com/sirvjs/v3/sirv.js"></script>
  <?php include("includes/footer.php"); ?>
</body>

</html>