<?php
session_start();
include_once 'classes/site_config.php';
include_once 'classes/minorityCheckout.php';


function fn_error_log($str)
{
    error_log(date("Y-m-d H:i:s") . ': ' . $str . "\n", 3, 'my_error_logs.log');
}

fn_error_log('MINORITY_VOICE_Order_Id is: ' . $_SESSION['MINORITY_VOICE_Order_Id']);
fn_error_log('MINORITY_VOICE_Order_Id is: ' . json_encode($_REQUEST));


// echo json_encode($_REQUEST);
// die();


// echo json_encode($_SESSION);
// die();
if (!isset($_SESSION['MINORITY_VOICE_Order_Id']) && empty($_SESSION['MINORITY_VOICE_Order_Id'])) {
    header('location:./');
} else {

    $order_id = $_SESSION['MINORITY_VOICE_Order_Id'];

    $data['payment_status'] = isset($_REQUEST['payment_status']) ? $_REQUEST['payment_status'] : '';
    $data['transaction_id'] = isset($_REQUEST['txn_id']) ? $_REQUEST['txn_id'] : '';



    $data['total_amount'] = isset($_REQUEST['mc_gross']) ? $_REQUEST['mc_gross'] : ''; // Paypal received amount
    $price_currency = isset($_REQUEST['mc_currency']) ? $_REQUEST['mc_currency'] : ''; // Paypal recieved currency type




    $currency = 'USD';
    $status = 'Completed';

    // print_r($price_currency$data
    // die();
    //  echo '<script>window.location="contactus.php";</script>';die();



    // Rechecking the product and currency details

    if ($data['payment_status'] == $status && $price_currency == $currency) {
        update_status($order_id, $data);
        admin_send_mail($order_id, "MINORITIES WITH A VOICE - Order Details");
        user_send_mail($order_id, "Your MINORITIES WITH A VOICE Order Details");

        echo '<script>window.location="./";</script>';
        die();
    }
}
?>

<!--<h1>Success</h1>-->