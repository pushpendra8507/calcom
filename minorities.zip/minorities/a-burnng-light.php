<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Minorities With A Voice</title>
    <meta name="description" content="#">
    <meta name="keywords" content="#">
    <?php include("includes/header-files.php");?>
</head>
<body>
  <?php include("includes/header.php");?>
<!-- Benner start -->
<div class="common-banner-area">
  <div class="overlay"></div>
  <div class="container">
    <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">A Burning Light</h1>
    </div>
  </div>
</div>
<!-- Benner end -->
<?php $burning = $burning_data->index(); ?>
<!-- Start About ======================= ====================== -->
  <section id="about-section" class="about-area">
    <div class="container">
      <div class="row wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s">
        <div class="col-lg-6 col-md-12 mb-4">	
          <div class="row">
            <div class="col-md-6 col-sm-6 pr-0 mb-4">
              <div class="about-img">
                <img class="img-fullwidth" src="<?php echo SITEURL; ?><?php echo isset($burning['photourl'])? $burning['photourl']: '' ?>" alt="">
              </div>
            </div>
            <div class="col-md-6 col-sm-6">
              <div class="about-img">
                <img class="img-fullwidth" src="<?php echo SITEURL; ?><?php echo isset($burning['photourl_1'])? $burning['photourl_1']: '' ?>" alt="">
              </div>
              <div class="about-img aboutimg2 mt-3">
                <img class="img-fullwidth" src="<?php echo SITEURL; ?><?php echo isset($burning['photourl_2'])? $burning['photourl_2']: '' ?>" alt="">
              </div>
            </div>
          </div>   
        </div>
        <div class="col-lg-6 col-md-12">
          <div class="about-details">
            <!-- <h2 class="mt-0"> <span >Creating Connection: </span> Ways to Support and Empower Homeless Communities</h2> -->
            <p><?php echo isset($burning['description'])? $burning['description']: '' ?></p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--End  About -->
    <?php include("includes/footer.php");?>
</body>
</html>