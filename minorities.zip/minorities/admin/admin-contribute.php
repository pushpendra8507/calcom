<?php
include_once '../classes/site_config.php';
include_once '../classes/admin_functions.php';
include_once '../classes/PaginateIt.php';
include_once '../classes/contribute.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}

if (isset($_REQUEST['did']) && !empty($_REQUEST['did'])) {
    $del_id = sanetize($_REQUEST['did']);
    if(delete($del_id)){
    header("location:admin-contribute.php");
}
}

$PaginateIt = new PaginateIt();
$per_page = 10;
$PaginateIt->SetItemsPerPage($per_page);
$PaginateIt->SetLinksToDisplay(10);

$item_count = count(index());

$PaginateIt->SetItemCount($item_count);

$contributes =index_limit($PaginateIt->GetSqlLimit()); 
//echo '<pre>'; print_r($contributes); die;
$PaginateIt->SetLinksFormat('&laquo; Back', ' ', 'Next &raquo;');

include("includes/top_header.php")
;
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>   
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Manage Contribute
                </div>
                <?php
                if ($item_count > 0) {
                    if (isset($_GET['page'])) {
                        $cnt = (($per_page * (int) $_GET['page']) - $per_page) + 1;
                    } else {
                        $cnt = 1;
                    }
                    ?>
                    <div class="panel-body">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="col">Sr. No</th>
                                    <th scope="col">Contribute Id</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Transaction Id</th>
                                    <th scope="col">Payment Status</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($contributes as $contri) {
                                    
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt ?></td>
                                        <td><?php echo $contri['contribute_number'] ?></td>
                                        <td><?php echo '$ '.$contri['price'] ?></td>
                                        <td><?php echo $contri['transaction_id'] ?></td>
                                        <td><?php echo $contri['payment_status'] ?></td>
                                        <td><?php echo date('m-d-Y H:i:s', strtotime($contri['updated_at'])) ?></td>
                                        <td><a href="admin-contribute.php?did=<?php echo $contri['id'] ?>" onclick="return confirm('Are you sure Permanently delete this Contribute?');"><span class="fa fa-trash"></span></a></td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                    if ($item_count > $per_page) {
                        ?>
                        <div class="pagination" style="float: right">Pages <?php echo $PaginateIt->GetPageLinks(); ?> </div>
                        <?php
                    }
                } else {
                    ?>
                    <center> <h4> Contribute Not Found !!</h4> </center>
                <?php } ?>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    
</body>
</html>