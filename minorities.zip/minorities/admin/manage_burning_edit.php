<?php
include_once '../classes/startup.php';
$core = new Core;
$burning_data = new MV_BurningLight;



if (isset($_POST['btn_submit'])) {
    $payload = [];
    $payload['description'] = isset($_POST['description']) ? $_POST['description'] : '';
    


    $update_id = $burning_data->update($_POST);
    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $update_id > 0) {
        $path = '../uploads/burning';
        $core->UploadImage($_FILES['fu_photo'], $path, 'minorities' . time() . $update_id, 'tbl_burning_light', 'photourl', 'id', 1);
    }


    if(isset($_FILES['fu_photo_1']) && $_FILES['fu_photo_1']['name'] != "" && $update_id > 0){
        $path = '../uploads/burning';
        $core->UploadImage($_FILES['fu_photo_1'], $path, 'minorities' . time(). $update_id, 'tbl_burning_light','photourl_1','id',1);
    } 


    if (isset($_FILES['fu_photo_2']) && $_FILES['fu_photo_2']['name'] != "" && $update_id > 0) {
        $path = '../uploads/burning';
        $core->UploadImage($_FILES['fu_photo_2'], $path, 'minorities' . time() . $update_id, 'tbl_burning_light', 'photourl_2', 'id', 1);
    }



    if ($update_id > 0) {
        $alert_data = array(
            "status" => "updated",
            "icon" => "success",
            "page_url" => "manage_burning.php"
        );
    } else {
        $alert_data = array(
            "status" => "Not updated",
            "icon" => "error",
            "page_url" => "manage_burning.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

$details = $burning_data->index();
$page_name = 'Burning';
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_burning.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Edit Burning
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">

                      
                            <div class="col-md-6">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image</label>
                                    <input type="file" name="fu_photo" id="image" />
                                </div>
                                <div class="col-md-6">
                                    <img width="80" id="showImage" src="<?php echo (!empty($details['photourl'])) ? '../' . $details['photourl'] : '' ?>" />
                                </div>
                                </div>
 
                                <div class="col-md-6">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image2</label>
                                    <input type="file" name="fu_photo_1" id="image1" />
                                </div>
                                <div class="col-md-6">
                                    <img width="80" id="showImage1" src="<?php echo (!empty($details['photourl_1'])) ? '../' . $details['photourl_1'] : '' ?>" />
                                </div>
                                </div>

                            

                                <div class="col-md-6">
                                <div class="col-md-6">
                                    <label for="inputEmail3">Image3</label>
                                    <input type="file" name="fu_photo_2" id="image2" />
                                </div>
                                <div class="col-md-6">
                                    <img width="80" id="showImage2" src="<?php echo (!empty($details['photourl_2'])) ? '../' . $details['photourl_2'] : '' ?>"  />
                                </div>
                                </div>
                     
                     
                     
                     
                
                            <div class="col-md-12">
                                <label for="inputEmail3">Description </label>
                                <textarea class="form-control description" name="description" required><?php echo (isset($details['description'])) ? html_entity_decode($details['description']) : '' ?></textarea>

                            </div>
                           
                        

                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>
</body>
<script type="text/javascript">
    $(document).ready(function() {
        $('#image').change(function(e) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#showImage').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $('#image1').change(function (e) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#showImage1').attr('src', e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>





<script>
    $(document).ready(function(){
        $('#image2').change(function(e){
            var reader = new FileReader();
            reader.onload = function(e){
                $('showImage2').attr('src',e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        });
    });
</script>

</html>