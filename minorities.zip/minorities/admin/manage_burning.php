<?php
include_once '../classes/startup.php';
$core = new Core;

$burning_data = new MV_BurningLight;

$top_data = $burning_data->index();

include("includes/top_header.php");


$page_name = 'Burning';
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Burning light Page
                    <a href="manage_burning_edit.php" title="Edit" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none; font-weight: bold;">Update Burning Text</a>
                </div>

                <div class="panel-body">
                    <table class="table table-dark">
                        <tbody>
                            <tr>
                                <td> <img width="70" style="border-radius: 100%;"   src="<?php echo isset($top_data['photourl']) ? '../' . $top_data['photourl'] : '' ?>" /> </td>
                                </tr>
                               
                            <tr>
                                <td>Description</td>
                                
                                <td><?php echo isset($top_data['description']) ? $top_data['description'] : '' ?></td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php include("includes/footer.php"); ?>
    </div>
</body>

</html>