<nav class="navbar navbar-default navbar-static-top">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle navbar-toggle-sidebar collapsed">
                MENU
            </button>
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">
                <img src="<?php echo SITELOGO ?>" style="width: 60% !important;padding: 6px;" class="img-responsive" alt="<?php echo ADMIN_TITLE; ?>">
            </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">      
            <ul class="nav navbar-nav navbar-right">
                <li><a href=".././" target="_blank" class="btn btn-primary"><i class="fa fa-globe" style="color: #000"></i> Visit Site</a></li>
                <li style="margin-right: 23px;margin-left: 5px;"><a href="logout.php"  class="btn btn-danger" ><i class="fa fa-power-off" style="color: #000"></i> Logout</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>