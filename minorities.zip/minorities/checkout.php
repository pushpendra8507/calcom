<?php
// session_start();
include_once 'classes/site_config.php';
include_once 'classes/admin_functions.php';
include_once 'classes/minorityCheckout.php';

if (isset($_POST['btn_submit'])) {

    $userinfo = [];
    $userinfo['size'] = $_POST['size'];
    $userinfo['price'] = $_POST['price'];

    // print_r($userinfo);


}

if (isset($_POST['place_order'])) {
    $data = [];
    $data['order_number'] = "MINORITY_VOICE" . rand(11111, 99999) . time();
    $data['shipping_fname'] = (isset($_POST['ship_fname']) && !empty($_POST['ship_fname'])) ? sanetize($_POST['ship_fname']) : '';
    $data['shipping_lname'] = (isset($_POST['ship_lname']) && !empty($_POST['ship_lname'])) ? sanetize($_POST['ship_lname']) : '';
    $data['shipping_company_name'] = (isset($_POST['company_name']) && !empty($_POST['company_name'])) ? sanetize($_POST['company_name']) : '';
    $data['country_name'] = (isset($_POST['country']) && !empty($_POST['country'])) ? sanetize($_POST['country']) : '';
    $data['shipping_address'] = (isset($_POST['street_address']) && !empty($_POST['street_address'])) ? sanetize($_POST['street_address']) : '';
    $data['shipping_appartment'] = (isset($_POST['appartment']) && !empty($_POST['appartment'])) ? sanetize($_POST['appartment']) : '';
    $data['shipping_town'] = (isset($_POST['town']) && !empty($_POST['town'])) ? sanetize($_POST['town']) : '';
    $data['shipping_state'] = (isset($_POST['state']) && !empty($_POST['state'])) ? sanetize($_POST['state']) : '';
    $data['shipping_zipcode'] = (isset($_POST['postal_code']) && !empty($_POST['postal_code'])) ? sanetize($_POST['postal_code']) : '';
    $data['shipping_phone'] = (isset($_POST['phone']) && !empty($_POST['phone'])) ? sanetize($_POST['phone']) : '';
    $data['shipping_email'] = (isset($_POST['email']) && !empty($_POST['email'])) ? sanetize($_POST['email']) : '';
    $data['shipping_note'] = (isset($_POST['note']) && !empty($_POST['note'])) ? sanetize($_POST['note']) : '';
    $data['size'] = (isset($_POST['size']) && !empty($_POST['size'])) ? sanetize($_POST['size']) : '';

    // $shirt_total = $userinfo['price'];


    $data['total_amount'] = (isset($_POST['amount']) && !empty($_POST['amount'])) ? sanetize($_POST['amount']) : '';
    $data['payment_mode'] = 'Paypal';


    $order_id = store($data);
    $_SESSION['MINORITY_VOICE_Order_Id'] = $order_id;


   

    if (($order_id > 0)) {
        echo '<script>window.location="payment-pay-to-paypal.php";</script>';
    }
}






?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Minorities With A Voice</title>
    <meta name="description" content="#">
    <meta name="keywords" content="#">

    <?php include("includes/header-files.php"); ?>
</head>

<body>


    <!-- Header Start -->
    <?php include("includes/header.php"); ?>
    <!-- Header End -->

    <!-- Benner start -->
    <div class="common-banner-area">
        <div class="overlay"></div>
        <div class="container">
            <div class="common-banner-title text-orange text-center">
                <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">Checkout</h1>
            </div>
            <div class="breadcrumb-area text-center">
                <div class="breadcrumb-overlay"></div>

            </div>
        </div>
    </div>

    <!--<div>-->
    <!--    <?php $testing = $userinfo['price']; ?>-->
    <!--    <h1>Price <?php echo $testing ?></h1>-->
    <!--    <h1><?php echo $userinfo['size'] ?></h1>-->

    <!--</div>-->

    <section class="checkout-page checkout checkout-sec">
        <div class="container">
            <div class="row">
                <!-- billing -->
                <div class="col-lg-8" data-select2-id="select2-data-8-vljm">
                    <div class="billing-details" data-select2-id="select2-data-7-y0l3">
                        <div class="title">
                            <h5>Shipping Address</h5>
                        </div>
                        <form action="" method="post">
                            <div class="row" data-select2-id="select2-data-6-7chi">
                                <div class="col-lg-6 col-md-6">
                                    <input type="text" placeholder="first name*" name="ship_fname" class="bill-input" required="">
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <input type="text" placeholder="last name*" name="ship_lname" class="bill-input" required="">
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" placeholder="company name (optional)" name="company_name" class="bill-input">
                                </div>
                                <div class="col-lg-12" data-select2-id="select2-data-5-2n5x">
                                    <select class="bill-input select select2-hidden-accessible" data-select2-id="select2-data-1-45ej" tabindex="-1" name="country">
                                        <option value="United State" data-select2-id="select2-data-3-i41q">United State</option>
                                        <option value="London" data-select2-id="select2-data-9-85qn">London</option>
                                        <option value="Canada" data-select2-id="select2-data-10-l8q9">Canada</option>
                                        <option value="India" data-select2-id="select2-data-11-ggww">India</option>
                                        <option value="South Africa" data-select2-id="select2-data-12-1gen">South Africa</option>
                                        <option value="Dubai" data-select2-id="select2-data-13-bw8j">Dubai</option>
                                        <option value="Albania" data-select2-id="select2-data-14-qm18">Albania</option>
                                    </select><span class="select2 select2-container select2-container--default select2-container--below" dir="ltr" data-select2-id="select2-data-2-556o" style="width: 992.656px;"><span class="selection"><span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-disabled="false" aria-labelledby="select2-3ac6-container"><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" placeholder="street address*" name="street_address" class="bill-input" required="">
                                </div>
                                <div class="col-lg-12">
                                    <input type="text" placeholder="apparments*" name="appartment" class="bill-input" required="">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="town/city*" name="town" class="bill-input" required="">
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" placeholder="state*" name="state" class="bill-input" required="">
                                </div>
                                <div class="col-lg-6">
                                    <input type="number" placeholder="post code*" name="postal_code" class="bill-input" required="">
                                </div>
                                <div class="col-lg-6">
                                    <input type="tel" placeholder="phone*" name="phone" class="bill-input" required="">
                                </div>
                                <div class="col-lg-12">
                                    <input type="email" placeholder="email address*" name="email" class="bill-input" required="">
                                </div>
                                <input type="hidden" name="amount" value="<?php echo $userinfo['price']; ?>">
                                <input type="hidden" name="size" value="<?php echo $userinfo['size']; ?>">
                            </div>
                            <!-- notes -->
                            <div class="notes">
                                <textarea class="bill-input" name="note" placeholder="Additional Information"></textarea>
                            </div>
                    </div>
                </div>
                <!-- order detail -->
                <div class="col-lg-4">
                    <div class="total-content">
                        <div class="title text-center">
                            <h5>your order</h5>
                        </div>
                        <div class="sub d-flex justify-content-between">
                            <p>Subtotal:</p>
                            <p>$<?php echo $userinfo['price'] ?></p>
                        </div>
                        <div class="checkout">
                            <div class="total d-flex justify-content-between">
                                <h6>total</h6>
                                <p>$<?php echo $userinfo['price'] ?>.00</p>
                            </div>
                            <!-- <label class="input-container">
                                <span>Paypal</span>
                                <input type="radio" name="payment_mode" value="Paypal" checked="">
                                <span class="checkmark"></span>
                            </label> -->
                            <button type="submit" name="place_order" class="button-style1">proceed to checkout <span class="btn-dot"></span></button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </section>

    <!-- end our mission -->

    <?php include("includes/footer.php"); ?>

</body>

</html>