<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minorities With A Voice</title>
  <meta name="description" content="#">
  <meta name="keywords" content="#">

  <?php include("includes/header-files.php"); ?>
</head>

<body>

  <?php include("includes/header.php"); ?>

  <!-- Benner start -->

  <div class="common-banner-area">
    <div class="overlay"></div>
    <div class="container">
      <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">Support Ukraine</h1>
      </div>
    </div>
  </div>

  <!-- Benner end -->
  <section class="blog-container">
    <div class="container">
      <div class="row">
        <!-- Blog Details Content Start -->
        <div class="col-lg-8 col-md-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".2s">
          <div class="blog-content-wrap">
            <div class="single-blog-post">
              <div class="post-thumbnail">
                <img src="<?php echo SITEURL; ?>images/support-ukraine.jpg" alt="post-thumbnail">
              </div>
              <div class="blog-details-content">
                <div class="post-head">
                  <div class="blog-details-title">
                    <h5 class="mb-2">The Fight to Support Ukraine</h5>
                  </div>
                </div>
                <!-- /.post-head -->
                <div class="blog-content-details">
                  <p>"Support Ukraine" is a call to action that urges individuals and nations to stand in solidarity with Ukraine during its ongoing struggle for sovereignty and independence. The country has faced numerous challenges in recent years, including political instability, economic hardship, and military conflict with Russia.</p>

                  <p>To support Ukraine means to recognize its right to self-determination and to advocate for its territorial integrity. It also means providing humanitarian aid to those affected by the conflict, promoting democratic values, and working towards a peaceful resolution to the conflict.</p>

                  <p>As a global community, it is our responsibility to support Ukraine in its efforts to build a stable and prosperous future. By standing together, we can help Ukraine overcome its challenges and achieve its full potential as a sovereign nation.</p>
                </div>
              </div>
            </div>
          </div>
          <!-- Blog Details Content end -->
        </div>
        <!-- Right sidebar start -->

        <div class="col-lg-4 col-md-12 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".2s">
          <div class="blog-righr-sidebar pt-2">
            <div class="single-sidebar bg-white px-2 py-3">
              <img src="<?php echo SITEURL; ?>images/scan.jpg">
            </div>
            <!-- Right sidebar end -->

            <div class="single-sidebar bg-white px-2 py-3">
              <form action="contribute-process.php" method="post">

                <div class="row">
                  <div class="col-sm-6 contact-border">
                    <div class="form-group">
                      <ul>
                        <li><input type="radio" value="5" name="price"> $5</li>
                        <li><input type="radio" value="10" name="price"> $10</li>
                        <li><input type="radio" value="15" name="price"> $15</li>
                        <li><input type="radio" value="20" name="price"> $20</li>
                        <li><input type="radio" value="Yes" name="price"> Other
                          <input type="text" name="other_price" id="other_price" class="form-control" onkeypress="return isNumberKey(event)" placeholder="Price (Don't use $ sign)" style="display: none">
                        </li>
                      </ul>
                    </div>

                    <div class="form-group">
                      <!--<input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="" />-->
                      <button type="submit" name="btn_submit" class="btn btn-flat contact-btn mr-2">Submit</button>
                    </div>
                  </div>
                </div>

              </form>
            </div>
            <!-- Right sidebar end -->
          </div>
        </div>
  </section>



  <?php include("includes/footer.php"); ?>

  <script>
    function isNumberKey(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
      if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
  </script>

  <script>
    $(document).ready(function() {
      $("input[name$='price']").change(function() {
        var div = $(this).val();
        if (div == 'Yes') {
          $("#other_price").show();
          $('#other_price').attr('required', true);
        } else {
          $("#other_price").hide();
          $('#other_price').attr('required', false);
        }
      });
    });
  </script>

</body>

</html>