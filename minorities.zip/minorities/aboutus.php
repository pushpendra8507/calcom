<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Minorities With A Voice</title>
    <meta name="description" content="#">
    <meta name="keywords" content="#">

    <?php include("includes/header-files.php");?>
</head>
<body>


  <!-- Header Start -->
    <?php include("includes/header.php");?>
    <!-- Header End -->

<!-- Benner start -->
<div class="common-banner-area">
  <div class="overlay"></div>
  <div class="container">
    <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">About us</h1>
    </div>
    <div class="breadcrumb-area text-center">
    <div class="breadcrumb-overlay"></div>
    
    </div>
  </div>
</div>
<!-- Benner end -->

    <!-- start our mission -->
   <?php $detail = $aboutus_data->index(2); ?>
    <section class="mission-section">
      <div class="container">
        <?php foreach($detail as $about_data){ ?>
        <div class="common-tittal text-center">
          <h2 class="text-uppercase wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".2s"><?php echo isset($about_data['title'])? $about_data['title']: '' ?></h2>
          <div class="title-icon">
            <img src="<?php echo SITEURL ?>images/charity.png" alt="">
          </div>
          <p class="wow fadeInRight" data-wow-duration="2s" data-wow-delay=".2s"><?php echo isset($about_data['description'])? $about_data['description']: '' ?></p>
        </div>
        <?php } ?> 
      </div> 
    </section> 

    <!-- end our mission -->

   <?php include("includes/footer.php");?>

</body>
</html>