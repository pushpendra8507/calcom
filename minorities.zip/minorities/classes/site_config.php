<?php
ob_start();
/*database credentials*/

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','minorities_db');
define('SITEURL', 'http://localhost/minorities/');
define('SITELOGO', 'http://localhost/minorities/images/logo.png');

// define('DB_HOST','localhost');
// define('DB_USER','');
// define('DB_PASSWORD','');
// define('DB_NAME','minorities_db');
// define('SITEURL', 'https://minoritieswithavoice.com/');
// define('SITELOGO', 'https://minoritieswithavoice.com/images/logo.png');






/*Manage Site Currency */
define('SITE_CURRENCY','$');
/*site title for admin pages*/
define('ADMIN_TITLE',"MINORITIES WITH A VOICE");







/** email setting */
define('MAIL_TITLE',"MINORITIES WITH A VOICE");
// Client id
define('ADMIN_EMAIL','minoritiesawithavoice@gmail.com');
// Developer Testing
// define('ADMIN_EMAIL','ravi02.agp@gmail.com');


define('FROM_EMAIL','no-reply@minoritiesawithavoice@gmail.com');
define('FROM_NAME',"MINORITIES WITH A VOICE");
define('BCC_EMAIL','pushpendra639263@gmail.com');



/** security settings */
define('SECURITY_KEY','i~am~iron~man');
define('ADMIN_SESSION','mv_admin');
define('ADMIN_SESSION_EMAIL','mv_admin_email');

?>