<?php
error_reporting(0);
session_start();
include_once 'site_config.php';


function store($data=array()){
	global $pdo;
	$stmt = $pdo->prepare("INSERT INTO `tbl_order`(`order_number`, `shipping_fname`, `shipping_lname`,  `shipping_company_name`, `shipping_address`, `shipping_appartment`, `shipping_town`, `shipping_state`, `shipping_zipcode`, `shipping_phone`, `shipping_email`, `shipping_note`, `size`, `total_amount`, `payment_mode`, `order_date`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,now())");

    $stmt->bindParam(1,$data['order_number']);
    $stmt->bindParam(2,$data['shipping_fname']);
    $stmt->bindParam(3,$data['shipping_lname']);
    $stmt->bindParam(4,$data['shipping_company_name']);
    $stmt->bindParam(5,$data['shipping_address']);
    $stmt->bindParam(6,$data['shipping_appartment']);
    $stmt->bindParam(7,$data['shipping_town']);
    $stmt->bindParam(8,$data['shipping_state']);
    $stmt->bindParam(9,$data['shipping_zipcode']);
    $stmt->bindParam(10,$data['shipping_phone']);
    $stmt->bindParam(11,$data['shipping_email']);
    $stmt->bindParam(12,$data['shipping_note']);
    $stmt->bindParam(13,$data['size']);
    $stmt->bindParam(14,$data['total_amount']);
    $stmt->bindParam(15,$data['payment_mode']);

	if($stmt->execute()){
		return $pdo->lastInsertId();
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}


    function admin_send_mail($orderid, $subject) {
    global $pdo;
    $stmh = $pdo->prepare("select * from tbl_order where odr_id=?");
    $stmh->bindParam(1, $orderid);
    $stmh->execute();
    $order_data = $stmh->fetch();


    define('ADMIN_EMAIL','ravi02.agp@gmail.com');
    define('MAIL_TITLE','MINORITIES WITH A VOICE');
    define('SITE_LOGO','https://minoritieswithavoice.com/images/logo.png');
    define('FROM_EMAIL','no-reply@minoritieswithavoice.com');
    $to = ADMIN_EMAIL;
    $message = '<!DOCTYPE HTML>
    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>'.MAIL_TITLE.'</title>
    </head>
    <body>
    <table style="width:100%; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="4" style="text-align: center;">
    <img src="'.SITE_LOGO.'" width="200px" class="img-responsive" alt="'.MAIL_TITLE.'">
    </th>
    </tr>
    <tr>
    <td colspan="2" style="border: 1px solid #ddd;"><strong>Order Number:  ' . $order_data['order_number'] . '</strong></td>
    <td colspan="2" style="border: 1px solid #ddd;"><strong>Order Date:  ' . date('m/d/Y H:i:s', strtotime($order_data['order_date'])) . '</strong></td>
    </tr>
    </thead>
    </table>


    <table style="width:50%; float:left; margin-bottom:50px; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="2" style="background-color: #000;color: #FFF;text-align: center;">Shipping Details</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>First Name</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_fname'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Last Name</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_lname'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Company</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_company_name'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Email</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_email'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Phone</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_phone'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Address</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_address'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Apartment</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_appartment'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Town / City</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_town'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>State / Country</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_state'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Zip Code</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_zipcode'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Note</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_note'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shirt Size</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['size'].'</td>
    </tr>
    <tr>
    </tbody>
    </table>';
    

    $message.='</tbody>


    <table style="width:50%; margin-top:10px; float:left; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="5" style="background-color: #000;color: #FFF;text-align: center;">Payment Details</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Payment Mode</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['payment_mode'].'</td>
    </tr>';
    if(($order_data['payment_mode']=='Paypal' && $order_data['payment_mode']=='' ) || ($order_data['payment_mode']=='Paypal' && $order_data['transaction_id']=='' ) )
    {
        $message.='<tr>
    <td style="border: 1px solid #ddd;"><label>Payment Status</label></td>
    <td style="border: 1px solid #ddd; color:red;">Pending</td>
    </tr>';
    }
        

    if(!empty($order_data['transaction_id'])){
        $message.='
        <tr>
        <td style="border: 1px solid #ddd;"><label>Transaction Id</label></td>
        <td style="border: 1px solid #ddd;">'.$order_data['transaction_id'].'</td>
        </tr>';
    }
    $message.='
    </tbody>
    </table>

    <table style="width:34.4%; float:right; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="5" style="background-color: #000;color: #FFF;text-align: center;">Sub Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Total Amount</label></td>
    <td style="border: 1px solid #ddd;">'."$". number_format($order_data["total_amount"],2).'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd; background:#000;"><label style="color:#fff; font-weight:600;">TOTAL</label></td>
    <td style="border: 1px solid #ddd; background:#000; color:#fff; font-weight:600;">'."$".number_format($order_data["total_amount"],3).'</td>
    </tr>

    </tbody>
    </table>
    </body>
    </html>';
    $fromMail = FROM_EMAIL;
    $fromName = MAIL_TITLE;
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'Bcc: mailto:ravi@agpt.in' . "\r\n";
	$headers .= 'Bcc: wxperts.co@gmail.com,wxperts.co@outlook.com' . "\r\n";
// 		echo $message;die();
    mail($to, $subject, $message,$headers);
}


function user_send_mail($orderid, $subject) {
    global $pdo;
    $stmh = $pdo->prepare("select * from tbl_order where odr_id=?");
    $stmh->bindParam(1, $orderid);
    $stmh->execute();
    $order_data = $stmh->fetch();
    $sEmail = $order_data['shipping_email'];

    define('FROM_EMAILS','no-reply@minoritieswithavoice.com');
    define('MAIL_TITLES','MINORITIES WITH A VOICE');
    $to = $sEmail;
    $message = '<!DOCTYPE HTML>
    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>'.MAIL_TITLES.'</title>
    </head>
    <body>
    <table style="width:100%; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="4" style="text-align: center;">
    <img src="'.SITE_LOGO.'" width="200px" class="img-responsive" alt="'.MAIL_TITLES.'">
    </th>
    </tr>
    <tr>
    <td colspan="2" style="border: 1px solid #ddd;"><strong>Order Number:  ' . $order_data['order_number'] . '</strong></td>
    <td colspan="2" style="border: 1px solid #ddd;"><strong>Order Date:  ' . date('m/d/Y H:i:s', strtotime($order_data['order_date'])) . '</strong></td>
    </tr>
    </thead>
    </table>


    <table style="width:50%; float:left; margin-bottom:50px; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="2" style="background-color: #000;color: #FFF;text-align: center;">Shipping Details</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>First Name</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_fname'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Last Name</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_lname'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Company</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_company_name'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Email</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_email'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Phone</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_phone'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Address</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_address'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Apartment</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_appartment'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Town / City</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_town'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>State / Country</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_state'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Zip Code</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_zipcode'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shipping Note</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['shipping_note'].'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Shirt Size</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['size'].'</td>
    </tr>
    <tr>
    </tbody>
    </table>';
    

    $message.='</tbody>


    <table style="width:50%; margin-top:10px; float:left; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="5" style="background-color: #000;color: #FFF;text-align: center;">Payment Details</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Payment Mode</label></td>
    <td style="border: 1px solid #ddd;">'.$order_data['payment_mode'].'</td>
    </tr>';
    if(($order_data['payment_mode']=='Paypal' && $order_data['payment_mode']=='' ) || ($order_data['payment_mode']=='Paypal' && $order_data['transaction_id']=='' ) )
    {
        $message.='<tr>
    <td style="border: 1px solid #ddd;"><label>Payment Status</label></td>
    <td style="border: 1px solid #ddd; color:red;">Pending</td>
    </tr>';
    }
        

    if(!empty($order_data['transaction_id'])){
        $message.='
        <tr>
        <td style="border: 1px solid #ddd;"><label>Transaction Id</label></td>
        <td style="border: 1px solid #ddd;">'.$order_data['transaction_id'].'</td>
        </tr>';
    }
    $message.='
    </tbody>
    </table>

    <table style="width:34.4%; float:right; border: 1px solid #ddd;">
    <thead>
    <tr>
    <th colspan="5" style="background-color: #000;color: #FFF;text-align: center;">Sub Total</th>
    </tr>
    </thead>
    <tbody>
    <tr>
    <td style="border: 1px solid #ddd;"><label>Total Amount</label></td>
    <td style="border: 1px solid #ddd;">'."$". number_format($order_data["total_amount"],2).'</td>
    </tr>
    <tr>
    <td style="border: 1px solid #ddd; background:#000;"><label style="color:#fff; font-weight:600;">TOTAL</label></td>
    <td style="border: 1px solid #ddd; background:#000; color:#fff; font-weight:600;">'."$".number_format($order_data["total_amount"],3).'</td>
    </tr>

    </tbody>
    </table>
    </body>
    </html>';
    $fromMail = FROM_EMAILS;
    $fromName = MAIL_TITLES;
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'Bcc: mailto:ravi@agpt.in' . "\r\n";
	$headers .= 'Bcc: wxperts.co@gmail.com,wxperts.co@outlook.com' . "\r\n";
// 		echo $message;die();
    mail($to, $subject, $message,$headers);
}



function update_status($order_id, $data = array()){
	global $pdo;
	$stmt = $pdo->prepare("UPDATE `tbl_order` SET  `transaction_id`=?, `payment_status`=?, `order_date`=now(), activatedstatus = 1  where odr_id=?");

	$stmt->bindParam(1,$data['transaction_id']);
	$stmt->bindParam(2,$data['payment_status']);
	$stmt->bindParam(3,$order_id);

	if($stmt->execute()){
		return $order_id;
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function get_price($order_id){
	global $pdo;
	$stmt = $pdo->prepare("select * from tbl_order where odr_id=?");
	$stmt->bindParam(1,$order_id);
	if($stmt->execute()){
		return $rtmt = $stmt->fetch(PDO::FETCH_ASSOC);
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}









?>