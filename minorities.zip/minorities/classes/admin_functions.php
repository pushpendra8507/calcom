<?php
session_start();
// error_reporting(0);
include_once 'site_config.php';
/* @var $pdo PDO */

function UploadImage( $fname, $folder, $upname, $tbl, $field, $updatefield, $id) {
    global $pdo;
    //print_r($fname);exit;
    $type = $fname["type"];
    $fname1 = $fname["name"];
    $path_info = pathinfo($fname1);
    $path_info['extension'];
    $ext = '.' . $path_info['extension'];
    if (($type = "image/jpg" || $type = "image/jpeg" || $type = "image/png" || $type = "image/bmp" || $type = "image/gif")) {
        $pathv = $folder . $upname . $ext;
        move_uploaded_file($fname["tmp_name"], '../' . $pathv);
        $stmt = $pdo->prepare("update $tbl set $field=? where $updatefield=?");
        $stmt->bindParam(1, $pathv);
        $stmt->bindParam(2, $id);
        $stmt->execute();
    }
}

function compress_image($source_url, $destination_url, $quality) {

    $info = getimagesize($source_url);

    if ($info['mime'] == 'image/jpeg')
        $image = imagecreatefromjpeg($source_url);

    elseif ($info['mime'] == 'image/gif')
        $image = imagecreatefromgif($source_url);

    elseif ($info['mime'] == 'image/png')
        $image = imagecreatefrompng($source_url);

    imagejpeg($image, $destination_url, $quality);
    return $destination_url;
}

function ValidateLogin($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("Select * from tbl_admin where BINARY  username=? and BINARY password=? And activatedstatus=1");
    $stmt->bindParam(1, $username);
    $stmt->bindParam(2, $password);
    $stmt->execute();
    if ($stmt->rowcount() == 0) {
        return '0';
    } else {
        $rs = $stmt->fetch();
        $_SESSION["admin"] = $rs["aid"];
        $_SESSION["email"] = $rs["username"];
        return '1';
    }
}

function ValidateVideoLogin($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("Select * from tbl_video_admin where BINARY  username=? and BINARY password=? And activatedstatus=1");
    $stmt->bindParam(1, $username);
    $stmt->bindParam(2, $password);
    $stmt->execute();
    if ($stmt->rowcount() == 0) {
        return '0';
    } else {
        $rs = $stmt->fetch();
        $_SESSION["videoAdmin"] = $rs["id"];
        $_SESSION["username"] = $rs["username"];
        return '1';
    }
}

function change_password($old_pass, $new_pass) {
    global $pdo;
    $stmt = $pdo->prepare("select * from tbl_admin where username=? and BINARY password=?");
    $stmt->bindParam(1, $_SESSION['email']);
    $stmt->bindParam(2, $old_pass);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $stm = $pdo->prepare("Update tbl_admin set password=? where aid=?");
        $stm->bindParam(1, $new_pass);
        $stm->bindParam(2, $_SESSION['admin']);
        $stm->execute();
        return '1'; // valid user
    } else {
        return '0'; //invalid user
    }
}

function sanetize($string) {
    $string = str_replace('"', '', $string);
    $string = str_replace("'", '', $string);
    $string = htmlspecialchars($string);
    return $string;
}

function custom_echo($x, $length) {
    if (strlen($x) <= $length) {
        echo $x;
    } else {
        $y = substr($x, 0, $length) . '...';
        echo $y;
    }
}

if (!function_exists('hash_equals')) {

    function hash_equals($str1, $str2) {
        if (strlen($str1) != strlen($str2)) {
            return false;
        } else {
            $res = $str1 ^ $str2;
            $ret = 0;
            for ($i = strlen($res) - 1; $i >= 0; $i--) {
                $ret |= ord($res[$i]);
            }
            return !$ret;
        }
    }

}

function csrf_token() {
    //$_SESSION['token'] = bin2hex(random_bytes(32));
    $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(32));
    $token = $_SESSION['token'];
    return $token;
}

function verify_token($token_s) {
    if (hash_equals($_SESSION['token'], $token_s)) {
        $token = 'yes';
        return $token;
    } else {
        $token = 'no';
        return $token;
    }
}

function alias_url($string) {
    $string = str_replace(array('[\', \']'), '', $string);
    $string = preg_replace('/\[.*\]/U', '', $string);
    $string = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $string);
    $string = htmlentities($string, ENT_COMPAT, 'utf-8');
    $string = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i',
        '\\1', $string);
    $string = preg_replace(array('/[^a-z0-9]/i', '/[-]+/'), '-', $string);
    return strtolower(trim($string, '-'));
}

function p_tag_remove($string){
    $string = str_ireplace('<p>','',$string);
    $string = str_ireplace('</p>','',$string);  
    $string = html_entity_decode($string);
    $string = strip_tags($string);
    return $string;
} 

function saveEvaluationData($data=array()){
    global $pdo;
    $name = isset($data['name'])?$data['name']:'';
    $date = isset($data['date'])?date('Y-m-d',strtotime($data['date'])):'';
    $staff_name = isset($data['staff_name'])?$data['staff_name']:'';
    $lead_name = isset($data['lead_name'])?$data['lead_name']:'';
    $details = json_encode($data);

    $stm = $pdo->prepare("INSERT INTO `tbl_evaloutaion_form`( `name`, `form_date`, `staff_name`, `lead_name`, `details`, `status`) VALUES (?,?,?,?,?,1)");
    $stm->bindParam(1,$name);
    $stm->bindParam(2,$date);
    $stm->bindParam(3,$staff_name);
    $stm->bindParam(4,$lead_name);
    $stm->bindParam(5,$details);

    if($stm->execute()){
        return $pdo->lastInsertId();
    }
    else{
        return 0;
    }

}



function updateFormImage($filepath,$form_id,$form_type){
    global $pdo;
    $stm = $pdo->prepare("INSERT INTO `tbl_form_doc`( `doc_url`, `form_id`, `form_type`, `status`) VALUES (?,?,?,1)");
    $stm->bindParam(1,$filepath);
    $stm->bindParam(2,$form_id);
    $stm->bindParam(3,$form_type);
    $stm->execute();
}

function saveUaBreathData($data=array()){
    global $pdo;
    $ambassador_name = isset($data['ambassador_name'])?$data['ambassador_name']:'';
    $date = isset($data['date'])?date('Y-m-d',strtotime($data['date'])):'';
    $done_by = isset($data['done_by'])?$data['done_by']:'';
    $details = json_encode($data);

    $stm = $pdo->prepare("INSERT INTO `tbl_ua_breath`( `name`, `form_date`, `done_by`,`details`, `status`) VALUES (?,?,?,?,1)");
    $stm->bindParam(1,$ambassador_name);
    $stm->bindParam(2,$date);
    $stm->bindParam(3,$done_by);
    $stm->bindParam(4,$details);

    if($stm->execute()){
        return $pdo->lastInsertId();
    }
    else{
        return 0;
    }
}

function updateUaBreathData($id, $data=array()){
    global $pdo;
    $ambassador_name = isset($data['ambassador_name'])?$data['ambassador_name']:'';
    $date = isset($data['date'])?date('Y-m-d',strtotime($data['date'])):'';
    $done_by = isset($data['done_by'])?$data['done_by']:'';
    $details = json_encode($data);

    $stm = $pdo->prepare("UPDATE `tbl_ua_breath` SET `name`=?, `form_date`=?, `done_by`=?, `details`=?, `date_added`=now() WHERE id = ?");
    $stm->bindParam(1,$ambassador_name);
    $stm->bindParam(2,$date);
    $stm->bindParam(3,$done_by);
    $stm->bindParam(4,$details);
    $stm->bindParam(5,$id);

    if($stm->execute()){
        return $id;
    }
    else{
        return 0;
    }
}


?>