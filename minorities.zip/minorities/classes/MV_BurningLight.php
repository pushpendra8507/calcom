<?php
class MV_BurningLight extends Database{
	public function __construct()
	{
		parent::__construct();
	}

    public function index(){
        $stmt =  $this->connection->prepare("SELECT * FROM `tbl_burning_light` where `id`=1");
        $stmt ->execute();

        return  $stmt->fetch(PDO::FETCH_ASSOC);
    }
   
    public function update($data){
        $description = isset($data['description'])? $data['description']:'';     

        
        $stmt = $this->connection->prepare("UPDATE `tbl_burning_light` SET `description`=?  WHERE `id`=1");
        $stmt->bindParam(1,$description);              
        return ($stmt->execute())?1:0;
    }
}
