<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Minorities With A Voice</title>
    <meta name="description" content="#">
    <meta name="keywords" content="#">

    <?php include("includes/header-files.php"); ?>
</head>

<body>
    <!-- Header Start -->
    <?php include("includes/header.php"); ?>
    <!-- Header End -->
    <!-- Benner start -->
    <div class="banner-section">
        <div id="carousel" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel" data-slide-to="0" class="active"></li>
                <li data-target="#carousel" data-slide-to="1"></li>
                <li data-target="#carousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="<?php echo SITEURL; ?>images/slide-1.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo SITEURL; ?>images/slide-2.jpg" alt="First slide">
                </div>
                <div class="carousel-item">
                    <img src="<?php echo SITEURL; ?>images/slide-3.jpg" alt="First slide">
                </div>

                <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>

    <!-- Start About -->
    <section id="about-section" class="about-section">
        <div class="container">
            <div class="common-tittal text-center">
                <h2 class="text-uppercase"><span>Welcome To</span> Minorities With A Voice</h2>
                <div class="title-icon">
                    <img src="<?php echo SITEURL; ?>images/charity.png" alt="">
                </div>
            </div>
            <?php $top_data = $top->index(); ?>
            <div class="row">
                <div class="col-lg-7 col-md-12">
                    <div class="about-details">
                        <p><?php echo isset($top_data['description']) ? $top_data['description'] : '' ?></p>
                        <a href="https://www.cardonationwizard.com/cars-for-charity/donate/donate-a-car-for-charity.html?ref=cars-for-charity&affilID=Minorities%20with%20A%20Voice%20Corp&affilName=Minorities%20with%20A%20Voice%20Corp" target="_blank">
                            <img src="<?php echo SITEURL;?>images/car-charity.png"></a>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 mb-4 bg-cover">
                    <img src="<?php echo SITEURL;?><?php echo isset($top_data['photourl']) ? $top_data['photourl'] : '' ?>">
                </div>
            </div>
        </div>
    </section>
    <!--End  About -->

    <div class="donate-page">
        <a href="<?php echo SITEURL;?>donate-now.php"><img src="<?php echo SITEURL; ?>images/donate.jpg"></a>
    </div>
    <?php $programe = $programe_data->index($homepage = 1); ?>
    <section class="mission-section">
        <div class="container">
            <div class="common-tittal text-center">
                <h2 class="text-uppercase">PROGRAMS</h2>
                <div class="title-icon">
                    <img src="<?php echo SITEURL; ?>images/charity.png" alt="">
                </div>
            </div>
            <div class="row">
                <?php foreach ($programe  as $data) { ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                        <div class="mission-contant text-center">
                            <div class="mission-img">
                                <img src="<?php echo SITEURL; ?><?php echo isset($data['photourl']) ? $data['photourl'] : '' ?>" alt="">
                            </div>
                            <div class="mission-text">
                                <h4><?php echo isset($data['title']) ? $data['title'] : '' ?></h4>
                                <p><?php echo isset($data['description']) ? $data['description'] : '' ?></p>
                                <a href="<?php echo isset($data['link']) ? $data['link'] : '' ?>" class="read">Read More<i class="fa fa-angle-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </section>


    <section class="covid-section clearfix">
        <div class="left-side">
            <img src="<?php echo SITEURL; ?>images/bike-flyer.jpg" alt="">
        </div>

    </section>

    <!-- Start Footer Bottom -->
    <?php include("includes/footer.php"); ?>
    <!-- End Footer -->

</body>

</html>