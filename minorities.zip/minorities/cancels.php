<?php 
include_once 'classes/site_config.php';
include_once 'classes/minorityCheckout.php';



function fn_error_log($str)
{
    error_log(date("Y-m-d H:i:s") .': '. $str ."\n", 3 , 'my_error_logs.log');
}
fn_error_log(json_encode($_REQUEST));
echo '<script>alert("payment failed");window.location="checkout.php";</script>';die();




?>