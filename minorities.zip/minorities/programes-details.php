<?php
include('classes/startup.php');
$core = new Core;
$programes_data = new MV_Programes;

if (!isset($_REQUEST['alias']) || empty($_REQUEST['alias'])) {
    header('location:index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Minorities With A Voice</title>
    <meta name="description" content="#">
    <meta name="keywords" content="#">

    <?php include("includes/header-files.php"); ?>
</head>

<body>
    <!-- Header Start -->
    <?php include("includes/header.php"); ?>
    <!-- Header End -->
    <?php $programes = $programes_data->get_details_by_alias($_REQUEST['alias']); ?>
    <!-- Benner start -->
    <div class="common-banner-area">
        <div class="overlay"></div>
        <div class="container">
            <div class="common-banner-title text-orange text-center">
                <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s"><?php echo isset($programes['title']) ? $programes['title'] : '' ?></h1>
            </div>
            <div class="breadcrumb-area text-center">
                <div class="breadcrumb-overlay"></div>

            </div>
        </div>
    </div>

    <!-- Benner end -->

    <!-- Start About -->
    <section id="about-section" class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-12">
                    <div class="about-details">
                        <p><?php echo isset($programes['description']) ? $programes['description'] : '' ?></p>
                    </div>
                </div>
                <div class="col-lg-5 col-md-12 mb-4 bg-cover">
                    <img src="<?php echo SITEURL; ?><?php echo isset($programes['photourl']) ? $programes['photourl'] : '' ?>">
                </div>
            </div>
        </div>
    </section>
    <!--End  About -->

    <!-- Start Footer Bottom -->
    <?php include("includes/footer.php"); ?>
    <!-- End Footer -->

</body>

</html>