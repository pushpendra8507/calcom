<?php 
include('classes/startup.php');
$core = new Core;
?>

<link rel="apple-touch-icon" sizes="180x180" href="<?php echo SITEURL ?>images/icon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo SITEURL ?>images/icon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo SITEURL ?>images/icon/favicon-16x16.png">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link type="text/css" href="<?php echo SITEURL ?>css/bootstrap.min.css" rel="stylesheet">
<link type="text/css" rel="stylesheet" href="<?php echo SITEURL ?>css/font-awesome.min.css" />
<link rel="stylesheet" href="<?php echo SITEURL ?>css/owl.carousel.min.css">
<link type="text/css" rel="stylesheet" href="<?php echo SITEURL ?>css/slick.css">
<link type="text/css" rel="stylesheet" href="<?php echo SITEURL ?>css/animate.min.css">
<link type="text/css" rel="stylesheet" href="<?php echo SITEURL ?>css/main.css">
<link type="text/css" rel="stylesheet" href="<?php echo SITEURL ?>css/responsive.css">