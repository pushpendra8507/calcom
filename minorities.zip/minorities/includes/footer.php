<?php 
include('classes/startup.php');
$core = new Core;
?>

<div class="footer-bottom">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="f-bottom">
        <p class="mb-0">Copyright © 2023 Minorities With A Voice. All Right Reserved.<br><a href="https://www.wxperts.co/website-development.php" target="_blank">Website Development</a> | <a href="https://www.wxperts.co/" target="_blank">Hosting</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Digital Marketing</a><br><a href="https://www.wxperts.co/" target="_blank"><img src="images/wxperts_powerdby.jpg" alt="wxperts"></a></p>
        </div>
      </div>
    </div>
  </div>
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>

<script src="<?php echo SITEURL; ?>js/jquery-3.5.0.min.js"></script>
<script src="<?php echo SITEURL; ?>js/bootstrap.min.js"></script>
<script src="<?php echo SITEURL; ?>js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo SITEURL; ?>js/main.js"></script>
<script src="<?php echo SITEURL; ?>js/owl.carousel.min.js"></script>
<script src="<?php echo SITEURL; ?>js/popper.min.js"></script>