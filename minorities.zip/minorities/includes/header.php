<?php
include('classes/startup.php');
$core = new Core;
$aboutus_data = new MV_Aboutus;
$programes_data = new MV_Programes;
$burning_data = new MV_BurningLight;
$programe_data = new MV_Programes_homes;
$contactus = new MV_Contactus;
$top = new MV_Top;

$top_data = $top->index();
$detail = $aboutus_data->index(2);

$services_data = $programes_data->index(2);

$burning = $burning_data->index();
$contact = $contactus->index();


?>

<header class="header sticky-header clearfix">
    <div class="header-top bg-theme-colored pt-2 pb-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-12">
                    <div class="header-top-contact">
                        <ul class="sm-text-center">
                            <li class=""> <i class="fa fa-phone text-white"></i> <a class="text-white" href="tel:<?php echo isset($contact['phone'])? $contact['phone']: '' ?>" target="_blank"><?php echo isset($contact['phone'])? $contact['phone']: '' ?></a> </li>
                            <li class=""> <i class="fa fa-map-marker text-white"></i> <a class="text-white" href="https://goo.gl/maps/aw9ShPdWQLWx8Kxw9" target="_blank"><?php echo isset($contact['address'])? $contact['address']: '' ?></a> </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-12">
                    <div class="header-top-btn">
                        <ul>
                            <li><a class="btn btn-default btn-flat btn-xs bg-light" href="<?php echo SITEURL ?>donate-now.php">Donate Now</a></li>
                            <li><a class="btn btn-default btn-flat btn-xs bg-light" href="<?php echo SITEURL ?>t-shirts.php">T-Shirts</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="menu-sticky">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="head-logo"><a href="<?php echo SITEURL; ?>"><img src="<?php echo SITEURL; ?>images/logo.png" alt="logo"></a></div>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto pt-2 pb-2">
                        <li class="nav-item"><a class="nav-link" href="<?php echo SITEURL; ?>">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo SITEURL; ?>aboutus.php">About Us</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Programs
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">

                                <?php foreach ($services_data as $service) { ?>
                                    <a class="dropdown-item" href="<?php echo SITEURL; ?><?php echo isset($service['alias']) ? $service['alias'] : '' ?>"><?php echo isset($service['title']) ? $service['title'] : '' ?></a>
                                <?php } ?>
                            </div>
                        </li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo SITEURL; ?>support-ukraine.php">Support Ukraine</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo SITEURL; ?>a-burnng-light.php">A Burning Light</a></li>
                        <li class="nav-item"><a class="nav-link" href="#">Events</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo SITEURL; ?>contactus.php">Contact Us</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>