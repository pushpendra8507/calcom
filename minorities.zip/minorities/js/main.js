// ==================================================
// Project Name  :  Payfund
// File          :  JS Base
// Version       :  1.0.0  
// Author        :  Bitspeck
// Developer:    :  MD.ABDULLAH FAHAD GAZI
// ==================================================
$(document).ready(function() {

  // preloader - start

  $(window).on('load', function () {
    $('#preloader').fadeOut('slow', function () { $(this).remove(); });
  });
  setTimeout(function()
  { $('#preloader').addClass('d-none'); }, 3000);
  // preloader - end

  // header - start

var headerId = $(".sticky-header");
  var headerTop = $(".sticky-header .header-top");

  $(window).on('scroll', function () {
    var amountScrolled = $(window).scrollTop();
    if ($(this).scrollTop() > 50) {
      headerId.removeClass("not-stuck");
      headerId.addClass("stuck");
      headerTop.addClass("display-none");
    } else {
      headerId.removeClass("stuck");
      headerId.addClass("not-stuck");
      headerTop.removeClass("display-none");
    }
  });

  // header - start


// client js start

  $('.client').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:3
        },
        1000:{
            items:5
        }
    }
});

// client js end

// client js start

  $('.mission').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    autoplay:true,
    autoplayTimeout:5000,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:2
        },
        1000:{
            items:3
        }
    }
});

// client js end

//-----------------------------------------------
 // top-to-back - start 
 // ----------------------------------------------
  if ($(window).scrollTop() < 100) {
    $('.scrollToTop').hide();
  }
  
  $(window).scroll(function() {
    if ($(this).scrollTop() > 100) {
      $('.scrollToTop').fadeIn('slow');
    } else {
      $('.back-to-top').fadeOut('slow');
    }
  });
  $('.scrollToTop').click(function(){
    $('html, body').stop().animate({scrollTop:0}, 5000, 'swing');
    return false;
  });
  
// -----------------------------------------------
 // top-to-back - start 
 // ----------------------------------------------

     $('#contact_form .contact-btn').click(function () {
        $.ajax({
            type: 'post',
            url: 'mail.php',
            data: $('#contact_form').serialize(),
            success: function () {
                $('#contact_form .contact-btn').attr('style', "background-color:#16C39A");
                $('#contact_form .contact-btn').siblings().html("<i style='color:#16C39A'>*</i> Email has been sent successfully");
            }
        });
        return false;
    });

});