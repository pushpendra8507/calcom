<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minorities With A Voice</title>
  <meta name="description" content="#">
  <meta name="keywords" content="#">

  <?php include("includes/header-files.php"); ?>
</head>
<body>

  <?php include("includes/header.php"); ?>

  <!-- Benner start -->

  <div class="common-banner-area">
    <div class="overlay"></div>
    <div class="container">
      <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">Donate Now</h1>
      </div>
    </div>
  </div>
  <!-- Benner end -->

  <!-- Divider: Contact -->
  <section class="contact-section">
    <div class="container">
      <div class="row pt-30">
        <div class="col-lg-8 col-md-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".2s">
          <!-- Contact Form -->
          <form action="contribute-process.php" method="post">

            <div class="row">
              <div class="col-sm-6 contact-border">
                <div class="form-group">
                  <ul>
                    <li><input type="radio" value="5" name="price"> $5</li>
                    <li><input type="radio" value="10" name="price"> $10</li>
                    <li><input type="radio" value="15" name="price"> $15</li>
                    <li><input type="radio" value="20" name="price"> $20</li>
                    <li><input type="radio" value="Yes" name="price"> Other
                      <input type="text" name="other_price" id="other_price" class="form-control" onkeypress="return isNumberKey(event)" placeholder="Price (Don't use $ sign)" style="display: none">
                    </li>
                  </ul>
                </div>
                <div class="form-group">
                  <!--<input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="" />-->
                  <button type="submit" name="btn_submit" class="btn btn-flat contact-btn mr-2">Submit</button>
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="col-lg-4 col-md-12 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".2s">
          <div class="row">
            <div class="col-sm-12 col-lg-12 col-md-6">
              <div class="media">
                <img src="<?php echo SITEURL; ?>images/scan.jpg">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <?php include("includes/footer.php"); ?>
  <script>
    function isNumberKey(evt) {
      var charCode = (evt.which) ? evt.which : event.keyCode
      if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
      return true;
    }
  </script>
  <script>
    $(document).ready(function() {
      $("input[name$='price']").change(function() {
        var div = $(this).val();
        if (div == 'Yes') {
          $("#other_price").show();
          $('#other_price').attr('required', true);
        } else {
          $("#other_price").hide();
          $('#other_price').attr('required', false);
        }
      });
    });
  </script>
</body>
</html>