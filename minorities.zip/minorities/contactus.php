<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minorities With A Voice</title>
  <meta name="description" content="#">
  <meta name="keywords" content="#">

  <?php include("includes/header-files.php"); ?>
</head>

<body>


  <?php include("includes/header.php"); ?>

  <!-- Benner start -->

  <div class="common-banner-area">
    <div class="overlay"></div>
    <div class="container">
      <div class="common-banner-title text-orange text-center">
        <h1 class="text-white banner-text wow zoomIn" data-wow-duration="2s" data-wow-delay=".2s">Contact Us</h1>
      </div>
    </div>
  </div>

  <!-- Benner end -->
  <?php $contact = $contactus->index(); ?>
  <!-- Divider: Contact -->
  <section class="contact-section">
    <div class="container">
      <div class="row pt-30">
        <div class="col-lg-4 col-md-12 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".2s">
          <div class="row">
            <div class="col-sm-12 col-lg-12 col-md-6">
              <div class="media contact-icon-box p-4 mb-3"> <a class="media-left pull-left" href="#"><i class="fa fa-map-o"></i></a>
                <div class="media-body"> <strong><a href="https://goo.gl/maps/aw9ShPdWQLWx8Kxw9" target="_blank"><?php echo isset($contact['address']) ? $contact['address'] : '' ?></a></strong>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-lg-12 col-md-6">
              <div class="media contact-icon-box p-4 mb-3"> <a class="media-left pull-left" href="#"> <i class="fa fa-phone"></i></a>
                <div class="media-body"> <strong><a href="tel:<?php echo isset($contact['phone']) ? $contact['phone'] : '' ?>"><?php echo isset($contact['phone']) ? $contact['phone'] : '' ?></a></strong>
                </div>
              </div>
            </div>

            <div class="col-sm-12 col-lg-12 col-md-6">
              <div class="media contact-icon-box p-4 mb-3"> <a class="media-left pull-left" href="#"><i class="fa fa-envelope-o"></i></a>
                <div class="media-body"> <strong><a href="mailto:<?php echo isset($contact['email']) ? $contact['email'] : '' ?>"><?php echo isset($contact['email']) ? $contact['email'] : '' ?></a></strong>
                </div>
              </div>
            </div>


          </div>
        </div>
        <div class="col-lg-8 col-md-12 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".2s">
          <h3 class="contact-text mb-5">Fill The Form</h3>
          <!-- Contact Form -->
          <form id="contact_form" name="contact_form" class="" action="#" method="post">

            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="form_name">Name <small>*</small></label>
                  <input id="form_name" name="name" class="form-control" type="text" placeholder="Enter Name" required="">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="form_email">Email <small>*</small></label>
                  <input id="form_email" name="email" class="form-control required email" type="email" placeholder="Enter Email" required="">
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="form_name">Subject <small>*</small></label>
                  <input id="form_subject" name="subject" class="form-control required" type="text" placeholder="Enter Subject" required="">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group">
                  <label for="form_phone">Phone</label>
                  <input id="form_phone" name="phone" class="form-control" type="text" placeholder="Enter Phone" required="">
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="form_name">Message</label>
              <textarea id="form_message" name="message" class="form-control required" rows="5" placeholder="Enter Message" required=""></textarea>
            </div>
            <div class="form-group">
              <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="" />
              <button type="submit" class="btn btn-flat contact-btn mr-2">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>


  <!-- contact: Google Map -->
  <div class="contact-map">
    <div class="container-fluid p-0">
      <div class="row">

        <!-- Google Map HTML Codes -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d53008.34635784234!2d-84.0800294811629!3d33.86333298358577!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88f5b98fbc051e39%3A0xb7b085b7f664e7e8!2sSnellville%2C%20GA%2030078!5e0!3m2!1sen!2sus!4v1680116029449!5m2!1sen!2sus" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

      </div>
    </div>
  </div>

  <?php include("includes/footer.php"); ?>
</body>

</html>