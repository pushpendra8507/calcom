<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>A-Team Painting & Home Care, LLC | Painting Contractor</title>
	<meta name="description" content="" />
	<meta name="keywords" content="">

	<?php include("includes/header-files.php");?>
	
</head>
<body>
	<!--section1 start-->	
	<?php include("includes/header.php");?>

	<!--section2 start-->
	<div class="temp_inner_banner wow fadeIn">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="heading">Painting Estimates</h1>
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
						<li class="breadcrumb-item active"><span class="paragraph">Painting Estimates</span></li>
					</ol>
				</div>
			</div>
		</div>
	</div>
	<!--section2 end-->

	<!--section3 start-->
	<div class="temp_blog_single_wrapper">
		<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="blog_single wow fadeInUp" data-wow-duration="1.5s">
						<div class="news_section text-center">
							<div class="temp_hover">
								<img src="assets/images/price1.jpg" alt="" class=" img-responsive">
								<div class="blog_single_overlay"></div>
							</div>
							<div class="blog_detail text-left">
								<p class="paragraph">A-Team Painting & Home Care, LLC proudly provides free, no-obligation estimates for our <a href="painting-company.php">painting services</a>. We think consumers deserve to know what they’re getting into. They deserve to make informed decisions that match their needs, wants, and budget. With our estimates, you’ll have everything you need to feel confident in your choice of painters. </p>
								<p class="paragraph">To request a quote, don’t hesitate to call us at  <strong><a href="tel:7622185701">(762) 218-5701</a></strong> today. We’ll be happy to provide one at no extra cost to you.</p>
							</div>
						</div>

						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">No-Obligation Painting Quotes</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">Our painting quotes come with no strings attached, no hidden fees. It’s our way of earning your trust and proving our worth as a service provider. After all, we know the value of our services. So why shouldn’t you?</p>
										<p class="paragraph">Our quotes are the perfect chance to figure out your budget for your project. You can request a quote, we’ll give you one, and you’re free to do what you like with it. We can also offer a range of options to save you time and money on your project. Feel free to compare our prices to our competitors, or keep our quote for future reference. After all, we know that when you need a painter, you’ll make the right choice. We know you’ll choose A-Team Painting & Home Care, LLC.</p>
									</div>
								</div>
							</div>
						</div>

												
						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">Precise Cost Assessments on All Painting</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">We’ve developed our cost assessments to clear, concise, and digestible. They provide an easy-to-understand breakdown of all the costs associated with our services—including time, labor, and products—so that you know where your money goes.</p>
										<div class="tab-content">
											<div id="10" class="tab-pane fade in active">
												<h3 class="subheading">When performing a cost assessment, we consider numerous factors that may affect the price of your project. Those factors include:</h3>

												<ul>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>The size of the surface area</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Costs of products and paints</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Type of project (exterior, interior)</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Any additional services required (wall repair, stucco repair, resurfacing)</span></li>
												</ul>
											</div>
										</div>
										<p class="paragraph">Our cost estimates are transparent, honest, and accurate. There are no sneaky surcharges or anything of the sort. We refrain from engaging in such business practices that may damage our reputation or harm the trust we enjoy with our clients. When we give you a price, we stick to it.</p>
									</div>
								</div>
							</div>
						</div>

						
						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">Personal Consultations for Every Painting Project</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">We’ll not only provide you with a no-obligation quote, but also a <strong>no-obligation consultation</strong>. It’s our way of showing our appreciation to every customer who comes our way. You can contact us, and we’ll book you in for a consultation at your earliest convenience. At the appointed time, we’ll come to your location and assess the proposed worksite.</p>
										<p class="paragraph">From there, we’ll sit down with you, discussing your needs before providing a range of service options for you. We can help you with color combinations, design ideas, and more, so you know all that’s available to you. And once we’re done, we’ll provide you with a detailed project plan and a quote for the job.</p>
										<p class="paragraph">Ask us as many questions as you like during the consultation. At the end of the day, we want you to feel confident in our services. We want you to see the value in them and to see why we’re the right team for you to choose.</p>
									</div>
								</div>
							</div>
						</div>
						
					</div>

					<div class="temp_sidebar">
					
					<div class="widget widget_resentpost padder_bottom50 wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="0.3s">
						<div class="post_slider">
							<div class="rp_img">
								<img src="assets/images/painting-estimates-service.jpg" alt="" class="img-responsive">
							</div>
							<div class="rp_content">
								<a href="tel:7622185701">Get Your Painting Estimate—Contact A-Team Painting & Home Care, LLC Today</a>
							</div>
						</div>
					</div>
					<div class="widget widget_categories padder_bottom50">
						<p class="paragraph">Start your renovation off strong with a no-obligation painting estimate. We’re ready to give you all the information you need to make your project a resounding success. If you are too, then don’t hesitate to get in touch with us.</p>
						<p class="paragraph">To request a quote, be sure to contact us today. <strong><a href="tel:7622185701">(762) 218-5701</a></strong> </p>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
	<!--section3 end-->



	<!--section5 start-->	
	<?php include("includes/footer.php");?>
</body>
</html>