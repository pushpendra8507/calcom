<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$special_data = new MV_Specail_Menu;

if (isset($_REQUEST['did'])) {
    $did = (int)$_REQUEST['did'];
    if ($special_data->delete($did)) {
        $alert_data = array(
            "status" => "Record Deleted",
            "icon" => "success",
            "page_url" => "manage_specail_menu.php"
        );
    } else {
        $alert_data = array(
            "status" => "Record Not Deleted",
            "icon" => "error",
            "page_url" => "manage_specail_menu.php"
        );
    }
    $core->set_sweetalert($alert_data);
} else if (isset($_REQUEST['homepage'])) {
    $status = (isset($_REQUEST['status']) && $_REQUEST['status'] == 1) ? 0 : 1;
    $special_data->update_homepage_status($_REQUEST['homepage'], $status);
    $alert_data = array(
        "status" => "Record Updated",
        "icon" => "success",
        "page_url" => "manage_specail_menu.php"
    );
    $core->set_sweetalert($alert_data);
}
$event = $special_data->index(2);




$page_name = 'Specail-Menu';

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="javascript:history.go(-1)" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    Specail Menu Page
                    <a href="manage_specail_menu_add.php" title="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add New</a>
                </div>

                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Sr. No</th>                           
                                <th scope="col">Title</th>
                                <th scope="col">Description</th>
                                <th scope="col">Action</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $cnt = 1;
                            foreach ($event as $events) {
                            ?>
                                <tr>
                                    <td><?php echo $cnt ?></td>
                                    
                                    <td><?php echo isset($events['title']) ? $events['title'] : '' ?></td>

                                    <td><?php echo isset($events['description']) ? $events['description'] : '' ?></td>
                                  

                                    <?php
                                    if ($events['homepage'] == 1) {
                                    ?>
                                        <td>
                                            <a href="manage_specail_menu.php?homepage=<?php echo $events['id'] . '&status=' . $events['homepage'] ?>"><span class="fa fa-check-circle" style="margin-right:1rem; color:green;"></span>Show On HomePage</a>
                                        </td>
                                    <?php
                                    } else {
                                    ?>
                                        <td>
                                            <a href="manage_specail_menu.php?homepage=<?php echo $events['id'] . '&status=' . $events['homepage'] ?>"><span class="fa fa-times-circle" style="margin-right:1rem; color:red;"></span>Show On HomePage</a>
                                        </td>
                                    <?php
                                    }
                                    ?>

                                    <td><a href="manage_specail_menu_add.php?eid=<?php echo $events['id'] ?>"><span class="fa fa-pencil-square-o"></span></a></td>
                                    <td><a href="manage_specail_menu.php?did=<?php echo $events['id'] ?>"><span class="fa fa-trash-o"></span></a></td>

                                </tr>
                            <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>


        <?php include("includes/footer.php"); ?>
    </div>

</body>

</html>