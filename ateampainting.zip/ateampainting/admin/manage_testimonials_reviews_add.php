<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$testimonial_review = new MV_Testimonial_Review;


if (isset($_POST['btn_submit'])) {

    
    $data['name'] = (isset($_POST['name']) && !empty($_POST['name'])) ? $_POST['name'] : '';
    $data['description'] = (isset($_POST['description']) && !empty($_POST['description'])) ? $_POST['description'] : '';
    

    if (empty($_POST['status'])) {
        $last_insert_id = $testimonial_review->store($data);
    } else {
        $last_insert_id = $testimonial_review->update($_POST['status'], $data);
    }

    if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $last_insert_id > 0) {
        $path = '../uploads/';
        $core->UploadImage($_FILES['fu_photo'], $path, 'blisstubs' . time() . $last_insert_id, 'tbl_testimonial_reviews', 'photourl', 'id', $last_insert_id);
    }
    if ($last_insert_id > 0) {
        if (!empty($_POST['status'])) {
            $alert_data = array(
                "status" => "Record Updated",
                "icon" => "success",
                "page_url" => "manage_testimonials_reviews.php"
            );
        } else {
            $alert_data = array(
                "status" => "Record Added",
                "icon" => "success",
                "page_url" => "manage_testimonials_reviews.php"
            );
        }
    } else {
        $alert_data = array(
            "status" => "something went wrong",
            "icon" => "error",
            "page_url" => "manage_testimonials_reviews.php"
        );
    }
    $core->set_sweetalert($alert_data);
}

if (isset($_REQUEST["eid"])) {
    $details = $testimonial_review->get_details($_REQUEST["eid"]);
}

$page_name = 'Testimonial_Reviews';

include("includes/top_header.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_testimonials_reviews.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"></a>
                    <?php echo isset($_REQUEST['eid']) ? "Edit" : "Add"; ?>
                    Testimonial Image
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" name="status" value="<?php echo (isset($_REQUEST['eid'])) ? $_REQUEST['eid'] : ""; ?>">

                       

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="inputEmail3">Name </label>
                                <input type="text" name="name" value="<?php echo (isset($details['name'])) ? $details['name'] : ''; ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>

                        <div class="form-group">
                                <div class="col-md-12">
                                    <label for="inputEmail3">Description</label>
                                    <textarea class="form-control description " name="description" required><?php echo (isset($details['description'])) ? html_entity_decode($details['description']) : '' ?></textarea>

                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="col-md-6">
                                <label for="inputEmail3">Image</label>
                                <input type="file" name="fu_photo" id="image" />
                                </div>
                                <div class="col-md-6">
                                    <img width="60" id="showImage" src="<?php echo (!empty($details['photourl']))?'../'.$details['photourl']:'' ?>" /> 
                                </div>
                            </div>                      
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <?php include("includes/footer.php"); ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#image').change(function(e) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>

</body>

</html>