<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
$core = new Core;
$pr_menu = new MV_Menu;


if (isset($_POST['btn_submit'])) {
    $data['name'] = (isset($_POST['name']) && !empty($_POST['name']))?$_POST['name']:'';
    
    
    if (empty($_POST['status'])) {
        $last_insert_id = $pr_menu->store($data);
    }
    else{
        $last_insert_id = $pr_menu->update($_POST['status'],$data);
    }

    

    if($last_insert_id>0){
        if(!empty($_POST['status'])){
            $alert_data= array(
                "status"=>"Record Updated",
                "icon"=>"success",
                "page_url"=>"manage_menu.php"
            );
            
        }
        else{
            $alert_data= array(
                "status"=>"Record Added",
                "icon"=>"success",
                "page_url"=>"manage_menu.php"
            );
        }
        
    }
    else{
        $alert_data= array(
            "status"=>"something went wrong",
            "icon"=>"error",
            "page_url"=>"manage_menu.php"
        );
    }
    $core->set_sweetalert($alert_data);
    
}

if(isset($_REQUEST["eid"])){
    $details = $pr_menu->get_details($_REQUEST["eid"]);
}



$page_name='Menu';

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_menu.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"> </a>Menu
                    <?php echo isset($_REQUEST['eid']) ? "Edit" : "Add"; ?>
                   
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                    <input type="hidden" name="status" value="<?php echo (isset($_REQUEST['eid'])) ? $_REQUEST['eid']: ""; ?>">
                        <div class="col-md-12">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="inputEmail3"> Category Name </label>
                                    <input type="text" name="name" value="<?php echo (isset($details['name']))?$details['name']:''; ?>" required="" class="form-control" id="inputEmail3" >
                                </div>
                            </div>
                        </div>
                        

 
                      


                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                    

   
                     


                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>
    
</body>
</html>