<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}

if(!isset($_REQUEST['vid']) || empty($_REQUEST['vid']))
{
    header('location:manage_menu_category.php');exit;
}
$core = new Core;
$pr_menu = new MV_Menu;

if(isset($_POST['btn_submit']))
{
    $payload = [];

          $payload['title']          = isset($_POST['title'])?$_POST['title']:'';
          $payload['description']    = isset($_POST['description'])?$_POST['description']:'';
          $payload['price']          = isset($_POST['price'])?$_POST['price']:'';   
          $payload['category_id']    = isset($_POST['vid'])?$_POST['vid']:'';


    if($last_insert_id = $pr_menu->store_item_details($payload));
    else{
        $last_insert_id = $pr_menu->updated($_POST['status'],$payload);
    }
    
        if (isset($_FILES['fu_photo']) && $_FILES['fu_photo']['name'] != "" && $last_insert_id>0) 
        {
            $path = '../uploads/menu-icon';
            $core->UploadImage($_FILES['fu_photo'], $path, 'testofcurry-'.time().$last_insert_id, 'tbl_menu_category', 'photourl', 'id', $last_insert_id);
        }

        if($last_insert_id>0){
            if(!empty($_POST['status'])){
                $alert_data= array(
                    "status"=>"Record Updated",
                    "icon"=>"success",
                    "page_url"=>"manage_menu_category_details.php?vid=".$_POST['vid']
                );                
            }
        $alert_data = array(
            "status"=>"Record Added",
            "icon"=>"success",
            "page_url"=>"manage_menu_category_details.php?vid=".$_POST['vid']
        );
    }
    else
    {
        $alert_data = array(
            "status"=>"Image Not Added",
            "icon"=>"error",
            "page_url"=>"manage_menu_category_details.php?vid=".$_POST['vid']
        );
    }

    $core->set_sweetalert($alert_data);
}
$category_data = $pr_menu->get_details($_REQUEST['vid']);

$category_images = $pr_menu->get_category_images($_REQUEST['vid']);

$gallery_item = $pr_menu->get_all_images_home($_REQUEST["vid"]);


$page_name = 'Menu';

include("includes/top_header.php");
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_menu_category_details.php?vid=<?php echo $_REQUEST['vid']; ?>" title="Back" class="btn btn-default"
                        style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img
                            src="images/back.png"></a>
                    <?php echo isset($_REQUEST['vid']) ? "Edit" : "Add"; ?>
                    Menu
                </div>
                <div class="panel-body">
                    <form method="POST" enctype="multipart/form-data" action="">
                    <input type="hidden" name="vid" value="<?php echo isset($_REQUEST['vid'])?$_REQUEST['vid']:'' ?>">

                        <div class="col-md-12">                                               
                            <label>Item Name</label>
                             <input type="text" name="title" class="form-control" required  id="inputEmail3" value="<?php echo (isset($gallery_item['title']))? $gallery_item ['title']:''; ?>">                             
                            </div>                            



                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Price </label>
                                    <input type="text" name="price" class="form-control " value="" ><?php echo (isset($gallery_item['price']))? $gallery_item ['price']:''; ?>
                                </div>
                            </div>                                          
                       


                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="inputEmail3"> Description </label>
                                    <textarea type="text" name="description" class="form-control  " value="" ><?php echo (isset($gallery_item['description']))? $gallery_item ['description']:''; ?></textarea>
                                </div>
                            </div>                                          
                        </div>
                        </div>


                       


                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT"
                                    class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#image').change(function (e) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#showImage').attr('src', e.target.result);
                }
                reader.readAsDataURL(e.target.files['0']);
            });
        });
    </script>

   

</body>

</html>