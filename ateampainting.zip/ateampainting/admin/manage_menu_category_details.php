<?php
include_once '../classes/startup.php';
if (!isset($_SESSION[ADMIN_SESSION])) {
    header('location:index.php');
}
if (!isset($_REQUEST['vid']) || empty($_REQUEST['vid'])) {
    header('location:manage_menu_category.php');
    exit;
}
$core = new Core;
$pr_menu = new MV_Menu;



if (isset($_REQUEST['did'])) {
    if ($pr_menu->delete_image($_REQUEST['did'])) {
        $alert_data = array(
            "status" => "Image Deleted",
            "icon" => "error",
            "page_url" => "manage_menu_category_details.php?vid=" . $_REQUEST['vid']
        );
        $core->set_sweetalert($alert_data);
    }
}

$category_data = $pr_menu->get_details($_REQUEST['vid']);

$category_images = $pr_menu->get_category_images($_REQUEST['vid']);


$page_name = 'Menu';

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <a href="manage_menu.php" title="Back" class="btn btn-default" style="float: left; padding: 5px; margin-top: -5px; margin-right: 5px; background: #fff; border: none;"><img src="images/back.png"> </a>
                    Menu
                    <a href="manage_menu_category_update.php?vid=<?php echo $_REQUEST['vid']; ?>" title="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add New</a>
                </div>

                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <!-- <tr>
                                <th scope="col" colspan="3"><?php echo isset($category_data['name']) ? $category_data['name'] : '' ?></th>
                            </tr> -->
                        </thead>
                        <tbody>

                            <tr>
                               <th>Sr.No</th>
                                <th>Item Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <!-- <th>Edit</th> -->
                                <th>Delete</th>
                            </tr>
                            <?php
                            $cnt= 1;
                            foreach ($category_images as $category_image) {
                            ?>
                                <tr>
                                      <td><?php echo $cnt; ?></td>
                                    <td><?php echo isset($category_image['title']) ? $category_image['title'] : '' ?></td>

                                    <td><?php echo isset($category_image['description']) ? $category_image['description'] : '' ?></td>


                                    <td><?php echo isset($category_image['price']) ? $category_image['price'] : '' ?></td>

                                    <!-- <td><a href="manage_menu_category_update.php?vid=<?php echo $_REQUEST['vid'] . '&did=' . $category_image['id']; ?>"><span class="fa fa-pencil-square-o" data-toggle="tooltip" data-placement="top" title="Edit"></span></a></td> -->
                                    <td><a href="manage_menu_category_details.php?vid=<?php echo $_REQUEST['vid'] . '&did=' . $category_image['id'] ?>"><i class="fa fa-trash-o"></i></a></td>
                                </tr>
                            <?php
                            $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>


        <?php include("includes/footer.php"); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#image').change(function(e) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#showImage').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(e.target.files['0']);
                });
            });
        </script>
    </div>

</body>

</html>