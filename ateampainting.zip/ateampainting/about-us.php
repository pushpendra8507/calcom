<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>AboutUs Top Quality Painting Company Near me in Blythe, GA</title>
	<meta name="description" content="A Team Painting and Home Care LLC Discover top quality painting services near Blythe, Augusta, Evans, Grovetown,  GA, delivering exceptional craftsmanship and transformative results Contact us for professional expertise and a stunning paintwork experience" />
	<meta name="keywords" content="Top Painting Company Near me, top-quality paintwork in Blythe, GA">
	<?php include("includes/header-files.php");?>
	
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="d-none">Top-Quality Painting Services near Blythe, GA</h1>
				<h2 class="d-none">Transformative Results and Professional Expertise</h2>
				<h3 class="heading">About A-Team Painting & Home Care, LLC</h3>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">about Us</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->

<!--section3 start-->
<div class="temp_about_wrapper wow slideInUp" data-wow-duration="1.5s">
<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="abhout_main wow fadeIn">
				<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12">
					<div class="abhout_left">
						<div class="bottompadder20">
							<h3 class="heading">Painting  <span>Company</span></h3>
						</div>
						<div class="bottompadder10">
							<p class="paragraph">A-Team Painting & Home Care, LLC is the top painting company in the local area, and with good reason, too. We’ve committed ourselves to providing top-quality paintwork at prices that anyone can afford. What’s more, we tailor our services to you and deliver stunning results.</p>
						</div>
						<div class="bottompadder30">
							<p class="paragraph">Are you ready to start your painting project? Give us a call now at <a href="tel:7622185701">(762) 218-5701</a> to speak with one of our professional painters.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-7 col-md-6 col-sm-6 col-xs-12">
					<div class="about_right">
						<img src="assets/images/a-team-painting-home-care-llc-about-us.jpg" alt="Top Painting Company Near me" class="img-responsive">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--section3 end-->



<!--section5 start-->	
<?php include("includes/footer.php");?>
</body>
</html>