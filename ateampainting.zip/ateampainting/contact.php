<?php
include_once 'ContactFunctions.php';

if(isset($_POST) && isset($_POST["btn_submit"]))
{
    if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
        echo '<script>window.location="./"</script>'; exit;
    }

    $name = $email = $phone = $form_subject =  $msge = "";
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {

        $secretKey  = '6LdLEzAnAAAAALTAWG_B0wDKS3T8ggvrLStIzKU-';
        $token    = $_POST["g-token"];
        $ip     = $_SERVER['REMOTE_ADDR'];
      
        if(empty($_POST["name"]))
        {
            echo '<script>window.location="./"</script>'; exit;
        } 
        else
        {
            $name = filterName($_POST["name"]);
            if($name == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
    
        if(empty($_POST["email"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $email = filterEmail($_POST["email"]);
            if($email == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }

        $phone = (isset($_POST["phone"]) && !empty($_POST["phone"]))? $_POST["phone"]: '';
        $form_subject = (isset($_POST["subject"]) && !empty($_POST["subject"]))? $_POST["subject"]: '';
        
        // Validate user message
        if(empty($_POST["description"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $msge = filterString($_POST["description"]);
            if($msge == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
 
        $url = "https://www.google.com/recaptcha/api/siteverify";
        $data = array('secret' => $secretKey, 'response' => $token, 'remoteip'=> $ip);

          // use key 'http' even if you send the request to https://...
        $options = array('http' => array(
            'method'  => 'POST',
            'content' => http_build_query($data)
        ));
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);
        //echo '<pre>';print_r($response);die();
        if($response->success)
        {
            define('BUSINESS_NAME','A-Team Painting & Home Care');
            define('FORM_TYPE','Contact Form');
            $to = 'bbbythigpen@gmail.com';
            // $to = 'pushpendra639263@gmail.com';
            // $to = 'ravi02.agp@gmail.com';
            $fromMail = 'no-reply@ateampaintingandhomecarellc.com';
            $fromName = BUSINESS_NAME;
            $subject = BUSINESS_NAME.' - '.FORM_TYPE;
            $message = '<html><head><title>'.BUSINESS_NAME.'</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
                <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

                <tr>
                <td height="25"  colspan="2"><center><strong>'.BUSINESS_NAME.'</strong></center></td>
                </tr>
                </table>
                <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
                    <tbody>
                        <tr>
                            <td width="100%" valign="top">
                                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                                    <tbody>     
                                        <tr>
                                            <td colspan="2"><center><strong>'.FORM_TYPE.'</strong></center></td>
                                        </tr>
                                        <tr>
                                            <td width="30%">Name:</td>
                                            <td width="70%">' . $name . '</td>
                                        </tr>
                                        <tr>
                                            <td>Email:</td>
                                            <td>' . $email . '</td>
                                        </tr>
                                        <tr>
                                            <td>Phone:</td>
                                            <td>' . $phone . '</td>
                                        </tr>
                                        <tr>
                                            <td>Subject:</td>
                                            <td>' . $form_subject . '</td>
                                        </tr>
                                        <tr>
                                            <td>Message:</td>
                                            <td>' . $msge . '</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div></body></html>';
                // To send HTML mail, the Content-type header must be set
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
                $headers .= 'From:'.$fromName." ".'<'.$fromMail.'>'."\r\n";
              $headers .= 'Bcc: wxperts.co@gmail.com,wxperts.co@outlook.com,contact@wxperts.co' . "\r\n";
                $message = str_replace("\'", "'", $message);
                //echo $message;exit;
                $send_mail = mail($to, $subject, $message, $headers);

                if($send_mail)
                {
                   echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
               }
               else 
               {
                   echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
               }
           }
           else
           {
            echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
           }
        }
}

?>







<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Contact Us- A-Team Painting & Home Care LLC</title>
    <meta name="description" content="Contact A-Team Painting & Home Care LLC for all your painting and home care needs. Our expert team is ready to assist you with top-quality services. Get in touch with us today to discuss your project" />
    <meta name="keywords" content="Top Painting Company in Blythe, GA,  Home Care in Georgia, Painting Company in Blythe, GA, Blythe Painting Contractor in Blythe, GA, Top Local Painting in Blythe, GA">
    <?php include("includes/header-files.php");?>
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h1 class="d-none">Contact A Team Painting & Home Care LLC</h1>


                <h2 class="d-none">Your Expert Partner for Painting and Home Care Services</h2>
				<h3 class="heading">Contact A-Team Painting & Home Care, LLC</h3>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">Contact</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->

<!--section3 start-->	
<div class="temp_getintouch_wrapper">
<svg class="svg_border2 color_gry" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-1 col-xs-offset-0">
				<div class="temp_contact_form_main wow fadeIn">
					<div class="temp_contact_form">
						<div class="row">
						    <form method="post">
						   <input type="hidden" id="g-token" name="g-token"/>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<input type="text" class="form-control" name="name" placeholder="Name">
								</div>
								<div class="form-group">
									<input type="email" class="form-control" name="email" placeholder="Email">
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="form-group">
									<input type="text" class="form-control" name="phone" placeholder="Phone">
								</div>
								<div class="form-group">
									<input type="text" class="form-control" name="subject" placeholder="Subject">
								</div>
								
							</div>
						</div>
						<div class="form-group message">
							<textarea class="form-control" name ="description" placeholder="Message"></textarea>
						</div>
						<button type="submit" id="submit" name ="btn_submit" class="temp_btn">submit</button>
						
					</div>
					 </form>
					<div class="temp_contact_form_right">
						<ul>
							<li><span><i class="fa fa-map" aria-hidden="true"></i></span><span> <a href="https://goo.gl/maps/6cSVmJQSnQpmdhKj9" target="_blank">Blythe, GA 30805-3536</a></span></li>
							<li><span><i class="fa fa-fax" aria-hidden="true"></i></span><span> <a href="tel:7622185701">(762) 218-5701</a>, <a href="tel:7063730056">(706) 373-0056</a></span></li>
							<li><a href="mailto:info@ateampainting.us"><span><i class="fa fa-envelope" aria-hidden="true"></i></span><span> info@ateampainting.us</span></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--section3 end-->

<!--section4 start-->
<div class="temp_map_section wow fadeIn">
	<div class="ed_element_wrapper_map">
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d858583.8594363633!2d-82.0360784!3d32.7964166!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x42580847961ec9c1%3A0x6fedc5b9e58ad35!2sA-Team%20Painting%20%26%20Home%20Care%2C%20LLC!5e0!3m2!1sen!2sus!4v1687814402715!5m2!1sen!2sus" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
</div>
<!--section4 end-->



<!--section5 start-->	
<?php include("includes/footer.php");?>
<script>
        grecaptcha.ready(function() {
        grecaptcha.execute('6LdLEzAnAAAAAFxwTADT63ykZKQw2GLH2lNMGKu1', {action: 'homepage'}).then(function(token) {
        
            document.getElementById("g-token").value = token;
        });
        });
</script>

</body>
</html>