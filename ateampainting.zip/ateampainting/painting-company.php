<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>A-Team Painting & Home Care, LLC | Painting Contractor</title>
	<meta name="description" content="" />
	<meta name="keywords" content="">

	<?php include("includes/header-files.php");?>
	
</head>
<body>
	<!--section1 start-->	
	<?php include("includes/header.php");?>

	<!--section2 start-->
	<div class="temp_inner_banner wow fadeIn">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h1 class="heading">Painting Company</h1>
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
						<li class="breadcrumb-item active"><span class="paragraph">Painting Company</span></li>
					</ol>
				</div>
			</div>
		</div>
	</div>
	<!--section2 end-->

	<!--section3 start-->
	<div class="temp_blog_single_wrapper">
		<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="blog_single wow fadeInUp" data-wow-duration="1.5s">
						<div class="news_section text-center">
							<div class="temp_hover">
								<img src="assets/images/price1.jpg" alt="" class=" img-responsive">
								<div class="blog_single_overlay"></div>
							</div>
							<div class="blog_detail text-left">
								<p class="paragraph">For all your residential, commercial, and industrial painting needs, A-Team Painting & Home Care, LLC is the name to know in the local area. We have a track record of impressive handiwork and outstanding client care, and our top priority is always customer satisfaction.</p>
								<p class="paragraph">Get in touch with us now at  <strong><a href="tel:7622185701">(762) 218-5701</a></strong> for the exceptional painting results you deserve.</p>
							</div>
						</div>

						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">A-Team Painting & Home Care, LLC’s Painting Services Tailored to You</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">No matter the project, we have you covered with custom paint selection and design.</p>
										<p class="paragraph">When it comes to your home, you deserve a living space that is a reflection of you. That’s why we work with you closely to determine the colors and finishes we’ll use. We offer our professional opinion in terms of matching your new paint to the current decor, but of course, all the final details are at your discretion.</p>
										<p class="paragraph">If you want your business to emulate your brand image, we will pinpoint the right paint colors, ensuring they work with your logo and theme. Depending on whether it’s a restaurant or a store, you may want to consider darker or lighter color palettes that blend nicely with the lighting.</p>
									</div>
								</div>
							</div>
						</div>

												
						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">Full-Service Painting Contractors</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">From design to execution, our team will guide you through the process, letting your vision become a reality. Using only the most cutting-edge painting techniques, we get the work done seamlessly, making sure not to miss a spot.</p>
										<div class="tab-content">
											<div id="10" class="tab-pane fade in active">
												<h3 class="subheading">Whether you’re in the residential, commercial, or industrial sector, we provide a full catalog of services that will both meet and exceed your expectations. We offer all the following:</h3>

												<ul>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Interior painting</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Exterior painting</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Drywall repair and installation</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Wallpaper removal</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Deck staining</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Pressure washing</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>Painting estimates</span></li>
													<li><i class="fa fa-check-square-o" aria-hidden="true"></i><span>And much more!</span></li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						
						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">Obligation-Free Consultations with Professional Painters</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">Start your painting project on the right foot by booking a no-obligation consultation at your earliest convenience. Whether you know what you want, or you’d like to bounce some ideas off of us, our team is ready to sit down and listen to you attentively.</p>
										<p class="paragraph">Once we’ve had enough time at the drawing board, we will finalize all the details and provide you with a quote upfront. You will be sure to know the cost and timeline at the onset, and our painters will let you know if anything changes along the line.</p>
									</div>
								</div>
							</div>
						</div>

						<div class="comments-area padder_bottom30 wow fadeIn" id="comments">
							<h3 class="comments-title padder_bottom20">Top-Rated Painting Company</h3>
							<div class="comment_wrapper wow slideInLeft" data-wow-duration="1.5s">
								<div class="comments">
									<div class="content">
										<p class="paragraph">There’s a good reason locals come to us for all their painting needs: we deliver on our promises. When you choose us for the job, you can always expect beautiful, long-lasting results that meet your specifications. Our certified and experienced <strong><a href="painting-estimates.php">painting contractors</a></strong> know how to get you the paintwork you deserve, and we’ll do it all promptly and professionally.</p>
									</div>
								</div>
							</div>
						</div>

												
					</div>

					<div class="temp_sidebar">
					
					<div class="widget widget_resentpost padder_bottom50 wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="0.3s">
						<div class="post_slider">
							<div class="rp_img">
								<img src="assets/images/painting-company-service.jpg" alt="" class="img-responsive">
							</div>
							<div class="rp_content">
								<a href="tel:7622185701">Call the Area’s Leading Painters Today</a>
							</div>
						</div>
					</div>
					<div class="widget widget_categories padder_bottom50">
						<p class="paragraph">If you’re looking for reliable and affordable professional painters, look no further than A-Team Painting & Home Care, LLC. We will collaborate with you on a game plan and make it happen before your eyes. As a local industry leader, you can expect the highest standard of quality with any of our painting services.</p>
						<p class="paragraph">Call us now at <strong><a href="tel:7622185701">(762) 218-5701</a></strong> to set up a consultation.</p>
					</div>
				</div>
				</div>
			</div>
		</div>
	</div>
	<!--section3 end-->



	<!--section5 start-->	
	<?php include("includes/footer.php");?>
</body>
</html>