<?php
class MV_Menu extends Database{

	public function __construct()
	{
		parent::__construct();
	}
	public function category_list()
	{
		$stmt =  $this->connection->prepare("SELECT * FROM `tbl_menu` where `status`=1");
        $stmt ->execute();

        return  $stmt->fetchAll(PDO::FETCH_ASSOC);
	}
	public function get_details($id)
	{
		$stmt =  $this->connection->prepare("SELECT * FROM `tbl_menu` where `status`=1 AND `id`=?");
		$stmt->bindParam(1, $id);
        $stmt ->execute();

        return  $stmt->fetch(PDO::FETCH_ASSOC);
	}
	public function update_details($id){
		$stmt = $this->connection->prepare("select * from tbl_menu_category where id=?");
		$stmt->bindParam(1,$id);
		if($stmt->execute()){
			return $rtmt = $stmt->fetch(PDO::FETCH_ASSOC);
		}
		else{
			die(print_r($stmt->errorInfo(), true));
		}
	}
	public function store($data=[])
	{
		$stmt = $this->connection->prepare("INSERT INTO `tbl_menu` (`name`,`status`) VALUES(?,1)");
		$stmt->bindParam(1, $data['name']);
		
		
		if($stmt->execute())
		{
			$last_insert_id = $this->connection->lastInsertId();
			return (isset($last_insert_id) && !empty($last_insert_id))?$last_insert_id:die(print_r($stmt->errorInfo(), true));
		}
		else
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}
	public function update($id,$data=[])
	{
		$stmt = $this->connection->prepare("UPDATE `tbl_menu` SET `name`=? WHERE `id`=?");
		$stmt->bindParam(1, $data['name']);		
		$stmt->bindParam(2, $id);
		if($stmt->execute())
		{
			return $id;
		}
		else
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}

	public function updated($id,$data=[])
	{
		$stmt = $this->connection->prepare("UPDATE `tbl_menu_category` SET `title`=?,`description`=?, `price`=?  WHERE `id`=?");
		$stmt->bindParam(1, $data['title']);
		
		$stmt->bindParam(2, $data['description']);
		$stmt->bindParam(3, $data['price']);
			
		$stmt->bindParam(4, $id);
		
		if($stmt->execute())
		{
			return $id;
		}
		else
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}

	public function get_category_images($category_id)
	{
		$stmt =  $this->connection->prepare("SELECT * FROM `tbl_menu_category` where `category_id`=? AND `status`=1 ");
		$stmt->bindParam(1, $category_id);
        $stmt ->execute();

        return  $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function get_all_images()
	{
		$stmt =  $this->connection->prepare("SELECT `gl`.*, `gct`.`name` FROM `tbl_menu_category` `gl` JOIN `tbl_menu` `gct` ON `gl`.`category_id`= `gct`.`id` where `gl`.`status`=1");
        $stmt ->execute();

        return  $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function get_all_images_home($category_id)
	{
		$stmt =  $this->connection->prepare("SELECT `gl`.*, `gct`.`name` FROM `tbl_menu_category` `gl` JOIN `tbl_menu` `gct` ON `gl`.`category_id`= `gct`.`id` where `gl`.`category_id`=?;");
		$stmt->bindParam(1, $category_id);
        $stmt ->execute();

        return  $stmt->fetchAll(PDO::FETCH_ASSOC);
	}

	public function store_item_details($data=[])
	{
		$stmt = $this->connection->prepare("INSERT INTO `tbl_menu_category` (`title`, `description`,`price`, `category_id`,`status`) VALUES(?,?,?,?,1)");
		$stmt->bindParam(1, $data['title']);
		
		$stmt->bindParam(2, $data['description']);
		$stmt->bindParam(3, $data['price']);
	
		$stmt->bindParam(4, $data['category_id']);
		
		if($stmt->execute())
		{
			$last_insert_id = $this->connection->lastInsertId();
			return (isset($last_insert_id) && !empty($last_insert_id))?$last_insert_id:die(print_r($stmt->errorInfo(), true));
		}
		else
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}


	public function get_details_by_alias($alias){
		$stmt = $this->connection->prepare("SELECT * FROM `tbl_menu_category` WHERE `alias` = ?  ");
		$stmt->bindParam(1,$alias);
		if($stmt->execute()){
			return $rtmt = $stmt->fetch(PDO::FETCH_ASSOC);

		}
	}


	public function delete_image($id)
	{
		$photoid = $this->get_details($id);
		if(!empty($photoid['photourl'])){
			unlink('../'.$photoid['photourl']);
		}

      
		
		$stmt = $this->connection->prepare("DELETE FROM `tbl_menu_category` WHERE `id`=?");
		$stmt->bindParam(1, $id);
		if($stmt->execute())
		{
			return true;
		}
		else
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}

	public function delete_category($id)
	{
		$stmt = $this->connection->prepare("DELETE FROM `tbl_menu` WHERE `id`=?");
		$stmt->bindParam(1, $id);
		if($stmt->execute())
		{
			return true;
		}
		else 
		{
			die(print_r($stmt->errorInfo(), true));
		}
	}

}

