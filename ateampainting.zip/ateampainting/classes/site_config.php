<?php
ob_start();
/*database credentials*/

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','db_ateampainting');
define('SITEURL', 'http://localhost/ateampainting');
define('SITELOGO', 'http://localhost/ateampainting/assets/images/logo.png');

// define('DB_HOST','localhost');
// define('DB_USER','root');
// define('DB_PASSWORD','');
// define('DB_NAME',  'db_ateampainting');
// define('SITEURL',  'https://www.ateampaintingandhomecarellc.com/');
// define('SITELOGO', 'https://www.ateampaintingandhomecarellc.com/assets/images/logo.png');





/*Manage Site Currency */
define('SITE_CURRENCY','$');
/*site title for admin pages*/
define('ADMIN_TITLE','A-Team Painting & Home Care, LLC');







/** email setting */
define('MAIL_TITLE',"A-Team Painting & Home Care, LLC");

define('ADMIN_EMAIL','bbbythigpen@gmail.com');

define('FROM_EMAIL','no-reply@ateampaintingandhomecarellc.com');
define('FROM_NAME','A-Team Painting & Home Care, LLC');
define('BCC_EMAIL','pushpendra639263@gmail.com');



/** security settings */
define('SECURITY_KEY','i~am~iron~man');
define('ADMIN_SESSION','mv_admin');
define('ADMIN_SESSION_EMAIL','mv_admin_email');



?>