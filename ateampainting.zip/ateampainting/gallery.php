<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Gallery - A-Team Painting & Home Care LLC</title>
	<meta name="description" content="Explore the impressive gallery of A-Team Painting & Home Care LLC. Witness the exceptional craftsmanship and transformative results in our portfolio. Get inspired and contact us for your painting and home care needs." />
	<meta name="keywords" content="Top Painting Company in Blythe, GA,  Home Care in Georgia, Painting Company in Blythe, GA, Blythe Painting Contractor in Blythe, GA, Top Local Painting in Blythe, GA">
	<?php include("includes/header-files.php");?>
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="d-none">Impressive Gallery at A-Team Painting & Home Care LLC</h1>
				<h2 class="d-none">Exceptional Craftsmanship and Transformative Results</h2>
				<h3 class="heading">Gallery A-Team Painting & Home Care, LLC</h3>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">Gallery</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->

<!--section3 start-->
<div class="temp_gallery_wrapper temp_project">
<svg class="svg_border2 color_gry" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="temp_gallery wow fadeIn">
				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-1.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-1.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-2.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-2.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-3.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-3.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-4.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-4.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-5.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-5.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-6.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-6.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-7.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-7.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-8.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-8.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-9.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-9.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-10.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-10.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-11.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-11.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-12.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-12.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-13.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-13.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-14.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-14.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-15.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-15.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>


				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-16.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-16.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-17.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-17.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-18.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-18.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-19.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-19.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-20.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-20.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-21.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-21.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-22.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-22.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-23.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-23.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-24.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-24.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-25.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-25.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-26.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-26.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-27.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-27.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-28.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-28.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-29.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-29.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-30.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-30.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-31.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-31.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-32.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-32.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-33.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-33.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-34.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-34.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-35.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-35.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
					<div class="gallery_section_wrapper text-center">
						<div class="gallery_section temp_hover">
							<img src="assets/images/a-team-project-36.jpg" alt="" class=" img-responsive">
								<a href="assets/images/a-team-project-36.jpg" class="image-link">
									<div class="temp_overlay">
										<div class="overlay_detail">
											<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
											<g>
												<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
													c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"></path>
												<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
													C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
													c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
													C318.424,257.208,257.206,318.416,181.956,318.416z"></path>
												<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"></path>
											</g>
											</svg></span>
										</div>
									</div>
								</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--section3 end-->





<!--section5 start-->	
<?php include("includes/footer.php");?>
</body>
</html>