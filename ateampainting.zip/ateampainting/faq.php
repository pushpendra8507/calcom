<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>A-Team Painting & Home Care, LLC | Painting Contractor</title>
	<meta name="description" content="" />
	<meta name="keywords" content="">

	<?php include("includes/header-files.php");?>
	
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="heading">Frequently Asked Questions</h1>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">Faq</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->

<!--section3 start-->
<div class="temp_accordions_wrapper">
<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="accordion">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="panel-group temp_accordion wow slideInLeft" data-wow-duration="1.5s" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
								What kind of paint do you use and why?</a>
							  </h4>
							</div>
							<div id="collapse1" class="panel-collapse collapse in">
							  <div class="panel-body">Depending on the job, we use either oil-based or water-based paints. If it’s for surfaces that experience a lot of wear and tear, we will use an oil-based paint due to its durability. If it’s for your interior walls and ceiling, a water-based paint will do the trick, and it will dry faster as well.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
								How many coats of paint are included in the quote?</a>
							  </h4>
							</div>
							<div id="collapse2" class="panel-collapse collapse ">
							  <div class="panel-body">If we’re painting dark on light, 2 coats of paint are included. If we’re painting light on dark, up to 6 coats are included so that we can achieve the color you want.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
								How long does a new paint job typically last?</a>
							  </h4>
							</div>
							<div id="collapse3" class="panel-collapse collapse">
							  <div class="panel-body">Our top-quality paint jobs will typically last you for 10 years. Still, if you want to maintain their pristine condition, we recommend scheduling paint touch-ups every 3 to 5 years.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse4">
								I have an older home that might have lead paint. How will it impact my painting project?</a>
							  </h4>
							</div>
							<div id="collapse4" class="panel-collapse collapse">
							  <div class="panel-body">Rest assured, we are certified to paint over lead paint. Our team will make sure to take all the necessary safety precautions and follow specific procedures to get the job done right. </div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse5">
								If a paint says it’s a paint and primer all-in-one, does that mean primer is mixed in with the paint?</a>
							  </h4>
							</div>
							<div id="collaps5" class="panel-collapse collapse">
							  <div class="panel-body">Even if it says that it’s a paint and primer all-in-one, there technically isn’t any primer in the mix. These are simply thicker paints with more coverage per coat.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse6">
								How do I prepare for your visit? </a>
							  </h4>
							</div>
							<div id="collapse6" class="panel-collapse collapse">
							  <div class="panel-body">We will handle the prep work so that you don’t need to worry about anything.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse7">
								Will there be a big disruption to my home while you are painting there?</a>
							  </h4>
							</div>
							<div id="collapse7" class="panel-collapse collapse">
							  <div class="panel-body">As professional painters, we do our best to keep out of your way. We will try to accommodate you by working at the least disruptive times. One way or another, we promise to keep the disruptions to a minimum as much as we can.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse8">
								Are you licensed and insured?</a>
							  </h4>
							</div>
							<div id="collapse8" class="panel-collapse collapse">
							  <div class="panel-body">Yes, our company is fully licensed, insured, and bonded.</div>
							</div>
						</div>
					</div>
				</div>

				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
					<div class="panel-group temp_accordion wow slideInLeft" data-wow-duration="1.5s" id="accordion">
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse9">
								Do you still use oil-based paints? What is the primary difference between oil- and latex-based paints? What are the benefits of each?</a>
							  </h4>
							</div>
							<div id="collapse9" class="panel-collapse collapse">
							  <div class="panel-body">Yes, we still use oil-based paints, especially on property exteriors, cabinets, doors, trims, and furniture. The primary differences between oil- and latex-based paints are drying time and durability. With oil-based paints, you can enjoy increased damage resistance and a smoother finish. With latex-based paints, you can expect shorter turnaround times.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse10">
								What types of environmentally friendly options do you offer? </a>
							  </h4>
							</div>
							<div id="collapse10" class="panel-collapse collapse ">
							  <div class="panel-body">We offer eco-friendly, non-toxic paint options to complete your painting project. Plus, we make use of leftover paints for moldings and trims and dispose of everything the right way.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse11">
								How can I find a painting company near me?</a>
							  </h4>
							</div>
							<div id="collapse11" class="panel-collapse collapse">
							  <div class="panel-body">If you live in the local area, A-Team Painting & Home Care, LLC is the team for the job. Contact us now to inquire.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse12">
								How can I get a painting estimate?</a>
							  </h4>
							</div>
							<div id="collapse12" class="panel-collapse collapse">
							  <div class="panel-body">You can get an accurate estimate by scheduling a consultation with our experts.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse13">
								Would you need to prime an area before painting it with another coat of latex paint?</a>
							  </h4>
							</div>
							<div id="collaps13" class="panel-collapse collapse">
							  <div class="panel-body">Generally, you would not need to prime an already painted wall, but at A-Team Painting & Home Care, LLC, we make sure your walls are clean before adding a new layer.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse14">
								What are the different kinds of paint finishes, and how do I select them for each room?</a>
							  </h4>
							</div>
							<div id="collapse14" class="panel-collapse collapse">
							  <div class="panel-body">The different kinds of paint finishes include eggshell, matte, semi-gloss, and satin. Our painting contractors will be happy to let you know which is best for each room of the house.</div>
							</div>
						</div>
						<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse15">
								How long does a paint job normally take?</a>
							  </h4>
							</div>
							<div id="collapse15" class="panel-collapse collapse">
							  <div class="panel-body">Every paint job is unique. A standard paint job will take a few days, but to know a more precise time frame, we suggest setting up a consultation with our painting contractors.</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--section3 end-->



<!--section5 start-->	
<?php include("includes/footer.php");?>
</body>
</html>