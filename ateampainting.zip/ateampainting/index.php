

<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Painting Company in Blythe, GA and Evans |A Team Painting </title>
	<meta name="description" content="A Team Painting and Home Care LLC Discover exceptional painting services in Blythe, GA, Evans and Top Local Painting in Georgia Contact us for professional painting expertise and explore comfortable living options." />
	<meta name="keywords" content="Top Painting Company in Blythe, GA,  Home Care in Georgia, Painting Company in Blythe, GA, Blythe Painting Contractor in Blythe, GA, Top Local Painting in Blythe, GA">
	<?php include("includes/header-files.php");?>
	<meta name="google-site-verification" content="Cedz_S0o9kFeYoOzxPSTHVfUzagZS05JmcOOBl5Acgk" />
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-FSLCM8SP5V"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'G-FSLCM8SP5V');
	</script>

</head>
<body>
	<!--section1 start-->	
	<?php include("includes/header.php");?>
	
	<!--section1 end-->
	<div class="temp_banner_slider">
		<div class="p_banner">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<div class="p_banner_right">
							<div class="animated fadeInUp">
								<h3 class="">Painting That Goes  <span>the Extra Mile</span></h3>
								<p>Servicing Grovetown, Evans, Harlem, Martinez, & the greater Augusta area</p>
								<p>Some of our clients include: homeowners, real estate agents, YMCA, Verizon, & The Augusta National Golf Club</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<svg class="svg_border" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	</div>


	<!--section3 start-->
	<div class="temp_about_wrapper wow slideInUp" data-wow-duration="1.5s">
		<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
		<div class="container">
			<div class="row">
				<div class="abhout_main wow fadeIn">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="abhout_left">
							<div class="bottompadder20">
								<h1 class="heading">A-Team Painting  <span>& Home Care, LLC</span></h1>
								<h2 class="d-none">Painting Company in Blythe, GA</h2>
							</div>
							<div class="bottompadder10">
								<p class="paragraph">A-Team Painting & Home Care, LLC has made a name for itself as an industry leader in the local area. Our team has provided property owners of all kinds with picture-perfect painting results, and we’re always looking forward to our next project.</p>
							</div>
							<div class="bottompadder30">
								<p class="paragraph">From design to execution, we streamline every task to get the job done swiftly and efficiently. What’s more, we take care to communicate with you consistently to ensure that you are satisfied with the finished product.</p>
							</div>
							<div class="bottompadder30">
								<p class="paragraph"><strong>For top-quality painting services at competitive rates, get in touch with us now at <a href="tel:7622185701">(762) 218-5701</a></strong>.</p>
							</div>
							<a href="https://www.google.com/search?q=A-Team+Painting+%26+Home+Care%2C+LLC+Blythe%2C+GA+30805-3536&oq=A-Team+Painting+%26+Home+Care%2C+LLC+Blythe%2C+GA+30805-3536&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIHCAEQABiiBNIBCDMxNTNqMGo3qAIAsAIA&sourceid=chrome&ie=UTF-8#lrd=0x42580847961ec9c1:0x6fedc5b9e58ad35,3,,,"><img src="assets/images/google-reviews.png" target="_blank"></a>
							<a href="about-us.php" class="temp_btn">read more</a>
							<a href="https://www.bbb.org/us/ga/blythe/profile/painting-contractors/a-team-painting-home-care-llc-0743-61267/customer-reviews"><img src="assets/images/bbb-logo.png" target="_blank"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--section3 end-->

	<!--section2 start-->
	<div class="temp_service_wrapper">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 text-center ">
					<div class="heading_wrapper wow rubberBand" data-wow-duration="2.5s">
						<h3 class="heading">Painting Services</h3>
						<div class="clearfix"></div>
						<div class="right bottompadder10">
							<img src="assets/images/heading_icon.png" alt="Top Painting Company in Blythe, GA">
						</div>
					</div>
				</div>
				<div class="temp_services wow fadeIn">
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						<div class="service_section service_boder1 wow slideInUp">
							<h3 class="subheading"><a href="commercial-painting.php">Commercial Painting</a></h3>
							<div>
								<p class="paragraph">A-Team Painting & Home Care, LLC is a local industry leader in commercial painting. We offer an extensive array of painting services tailored to commercial spaces, both big and small. From the initial consultation to the final follow-up, we make sure to get every detail right, checking off your specifications and requirements along the way.</p>
								<a href="commercial-painting.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						<div class="service_section wow slideInUp" data-wow-delay="0.5s">
							<h3 class=" subheading"><a href="deck-painting.php">Deck Painting</a></h3>
							<div>
								<p class="paragraph">A-Team Painting & Home Care, LLC is proud to be the area’s leading local deck painting company. We help you revitalize your deck, giving it the picture-perfect finish so that it can stay in great shape year after year. Our premium-quality paints will protect your deck from the weather, boost your property’s curb appeal, and give you the elegant exterior you’ve always wanted.</p>
								<a href="deck-painting.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
						<div class="service_section wow slideInUp" data-wow-delay="0.8s">
							<h3 class="subheading"><a href="deck-staining.php">Deck Staining</a></h3>
							<div>
								<p class="paragraph">Protect your deck with a quality stain from A-Team Painting & Home Care, LLC. We’re proud to offer the area’s top-rated deck staining services, delivering top-tier results at exceptionally fair prices. With a stain from us, you’ll able to enjoy your deck to the fullest, adding years of longevity onto its life while also increasing its aesthetic appeal.</p>
								<a href="deck-staining.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
						<div class="service_section service_boder1 service_boder6 wow slideInUp" data-wow-delay="1.3s">
							<h3 class="subheading"><a href="exterior-brick-painters.php">Exterior Brick Painters</a></h3>
							<div>
								<p class="paragraph">If you’re looking for quality, integrity, and reliability, A-Team Painting & Home Care, LLC exterior brick painters have it all. We provide you with top of the line brick painting services tailored to your wants and needs, and we complete the work in record time, all for a competitive price.</p>
								<a href="exterior-brick-painters.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						<div class="service_section service_boder6 wow slideInUp" data-wow-delay="1.6s">
							<h3 class="subheading"><a href="faux-painting.php">Faux Painting</a></h3>
							<div>
								<p class="paragraph">Transform your interior with the faux painting services of A-Team Painting & Home Care, LLC. We’re proud to be local area’s leading faux painting specialist. With our skill and expertise, we can recreate the look of such sought-after materials as hardwood, stone, and marble—all at a fraction of the cost of the real thing. For elegant aesthetics and affordable prices, ours is the name to remember.</p>
								<a href="faux-painting.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						<div class="service_section service_boder6 wow slideInUp" data-wow-delay="1.9s">
							<h3 class="subheading"><a href="exterior-painting.php">Exterior Painting</a></h3>
							<div>
								<p class="paragraph">Upgrade the look of your home or business with A-Team Painting & Home Care, LLC exterior painting services. We offer immaculate handiwork, excellent client care, and the most competitive prices. Our team will help you figure out the best way to redefine your property, highlighting its leading attributes, and increasing its property value.</p>
								<a href="exterior-painting.php" class="temp_btn">read more</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--section2 end-->

	<!--section3 start-->
	<div class="temp_service_wrapper painting_service">
		<svg class="svg_border1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" 	preserveAspectRatio="none" height="50" width="100%"> <path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
			c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
			c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path> </svg>
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 text-center">
						<div class="heading_wrapper wow rubberBand" data-wow-duration="2.5s">
							<h3 class=" heading text-white">Other Services</h3>
							<div class="clearfix"></div>
							<div class="right bottompadder10">
								<img src="assets/images/heading_icon.png" alt="Home Care in Georgia">
							</div>
						</div>
					</div>
					<div class="temp_services wow fadeIn">
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInLeft" data-wow-duration="1.5s">

								<div class="service_right">
									<h3 class="subheading"><a href="drywall-installation.php">Drywall Installation</a></h3>
									<p class="paragraph">Whether it’s for new construction or your current property, A-Team Painting & Home Care, LLC provides seamless drywall installation for incredibly affordable prices.</p>
									<a href="drywall-installation.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInRight" data-wow-duration="1.5s">

								<div class="service_right">
									<h3 class="subheading"><a href="drywall-repair-services.php">Drywall Repair Services</a></h3>
									<p class="paragraph">For all your drywall repair needs, A-Team Painting & Home Care, LLC is the one for the job. We are a team of certified and experienced contractors specializing in repairing and restoring drywall to its original condition. We work quickly and efficiently to patch up the damage, leaving you with a fresh new wall and endless possibilities.</p>
									<a href="drywall-repair-services.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="0.5s">

								<div class="service_right">
									<h3 class="subheading"><a href="epoxy-flooring.php">Epoxy Flooring</a></h3>
									<p class="paragraph">A-Team Painting & Home Care, LLC is the top epoxy floor coating company in the local area. Whether you are a homeowner who would like to fortify your garage floor, or a factory owner interested in the many benefits of epoxy flooring, we’re the ones for the job.</p>
									<a href="epoxy-flooring.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="0.5s">

								<div class="service_right">
									<h3 class="subheading"><a href="power-washing-services.php">Power Washing Services</a></h3>
									<p class="paragraph">If you’re on the lookout for expert power washing services, there’s only one name you should know, and that’s A-Team Painting & Home Care, LLC.</p>
									<a href="power-washing-services.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="1s">

								<div class="service_right">
									<h3 class="subheading"><a href="wallpaper-removal-services.php">Wallpaper Removal Services</a></h3>
									<p class="paragraph">A-Team Painting & Home Care, LLC is the leading wallpaper removal experts serving the local area. Using the latest methods, tools, and non-destructive techniques, we remove wallpaper with speed and efficiency, giving you just what you need for future interior renovations.</p>
									<a href="wallpaper-removal-services.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-xs-12 ">
							<div class="service_section wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="1s">

								<div class="service_right">
									<h3 class="subheading"><a href="pressure-washing-services.php">Pressure Washing Services</a></h3>
									<p class="paragraph">If you want to clear out all that dirt and grime in record time, A-Team Painting & Home Care, LLC has you covered with premium pressure washing services at affordable price points.</p>
									<a href="pressure-washing-services.php" class="temp_btn">read more</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<svg class="svg_border" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
		</div>
		<!--section3 end-->

		<!--section4 start-->
		<div class="temp_about_banner wow fadeIn">
			<svg class="svg_border1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" 	preserveAspectRatio="none" height="50" width="100%"> <path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
				c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
				c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path> </svg>
				<div class="container">
					<div class="row">
						<div class="abhout_main about_sec2">
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
								<div class="about_right">
									<img src="assets/images/full-service.jpg" alt="Blythe Painting Contractor in Blythe, GA" class="img-responsive">
								</div>
							</div>
							<div class="col-lg-8 col-md-6 col-sm-6 col-xs-12">
								<div class="abhout_left">
									<div class=" bottompadder20">
										<h3 class="heading">A Full-Service  <span>Painting Company</span></h3>
									</div>
									<div class="bottompadder10">
										<p class="paragraph">From start to finish, we have you covered for all your painting needs. We are skilled, precise, and highly qualified to bring your project to life first on paper, and then in real life.</p>
									</div>
								</div>
							</div>
						</div>

						<div class="abhout_main about_sec2">
							<div class="col-lg-8 col-md-6 col-sm-6 col-xs-12">
								<div class="abhout_left">
									<div class=" bottompadder20">
										<h3 class="heading">Consult with   <span>Professional Painters</span></h3>
									</div>
									<div class="bottompadder10">
										<p class="paragraph">When you want to redefine your property with fresh paint, the first step is to schedule a commitment-free consultation with us. Our professionals will meet with you to discuss the details of your project, whether you have an idea in mind or not.<br>

										From there, we will provide you with a transparent estimate that clearly outlines the services, the cost, and the timeline. To avoid unnecessary confusion, we will go over it with you to confirm any specifications. With us, the painting process is as smooth as it can be.</p>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
								<div class="about_right">
									<img src="assets/images/professional-painters.jpg" alt="Top Local Painting in Blythe, GA" class="img-responsive">
								</div>
							</div>
						</div>

						<div class="abhout_main about_sec2">
							<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
								<div class="about_right">
									<img src="assets/images/customized-painting.jpg" alt="Top Painting Company in Blythe" class="img-responsive">
								</div>
							</div>
							<div class="col-lg-8 col-md-6 col-sm-6 col-xs-12">
								<div class="abhout_left">
									<div class=" bottompadder20">
										<h3 class="heading">A-Team Painting & Home Care, LLC’s <span>Customized Painting Services</span></h3>
									</div>
									<div class="bottompadder10">
										<p class="paragraph">When you want to redefine your property with fresh paint, the first step is to schedule a commitment-free consultation with us. Our professionals will meet with you to discuss the details of your project, whether you have an idea in mind or not.<br>

										From there, we will provide you with a transparent estimate that clearly outlines the services, the cost, and the timeline. To avoid unnecessary confusion, we will go over it with you to confirm any specifications. With us, the painting process is as smooth as it can be.</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--section4 end-->

			<!--section4 start-->
			<div class="temp_team_wrapper">
				<div class="container">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center ">
							<div class="heading_wrapper wow rubberBand" data-wow-duration="2.5s">
								<h3 class=" heading">Detail-Oriented, Experienced Painters</h3>
								<div class="clearfix"></div>
								<div class="right bottompadder10">
									<img src="assets/images/heading_icon.png" alt="Home Care in Georgia">
								</div>
							</div>
							<h3><strong>Top-Quality Results</strong></h3>
							<p class="paragraph italic">With many years of experience and training under their belts, our professional painters are second to none in the local community. From color selection to paint touch-ups, we work quickly yet meticulously to get the job done to your liking.</p>
							<p class="paragraph italic">No matter the job, we use top of the line paints, primers, brushes, and rollers to provide the highest standard of quality. For beautiful, long-term results, our team knows to prime the walls well before applying a precise number of coats.</p>
							<p class="paragraph italic">You will be sure to adore how your property looks once we’ve completed the job.</p>
						</div>

					</div>
				</div>
			</div>
			<!--section4 end-->


			<!--section7 start-->
			<div class="temp_gallery_wrapper">
				<svg class="svg_border1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" 	preserveAspectRatio="none" height="50" width="100%"> <path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
					c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
					c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path> </svg>
					<div class="container">
						<div class="row">
							<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 text-center ">
								<div class="heading_wrapper wow rubberBand" data-wow-duration="2.5s">
									<h3 class="heading text-white">Our Projects</h3>
									<div class="clearfix"></div>
									<div class=" right bottompadder10">
										<img src="assets/images/heading_icon.png" alt="Painting Company in Blythe, GA" width="205" height="32">
									</div>
								</div>
							</div>
							<div class="temp_gallery">
								<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 ">
									<div class="gallery_section_wrapper text-center">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-1.jpg" alt="Blythe Painting Contractor in Blythe" class=" img-responsive">
											<a href="assets/images/project-1.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>

													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
									<div class="gallery_section_wrapper text-center wow fadeInUp" data-wow-duration="1.5s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-2.jpg" alt="Top Local Painting in Blythe" class=" img-responsive">
											<a href="assets/images/project-2.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
									<div class="gallery_section_wrapper  text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.5s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-3.jpg" alt="" class="img-responsive">
											<a href="assets/images/project-3.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
									<div class="gallery_section_wrapper  text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-4.jpg" alt="Painting Company in Blythe, GA" class=" img-responsive">
											<a href="assets/images/project-4.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
									<div class="gallery_section_wrapper  text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.5s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-5.jpg" alt="" class=" img-responsive">
											<a href="assets/images/project-5.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 ">
									<div class="gallery_section_wrapper  text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="2s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-6.jpg" alt="" class=" img-responsive">
											<a href="assets/images/project-6.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
								<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 ">
									<div class="gallery_section_wrapper text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="2.5s">
										<div class="gallery_section temp_hover">
											<img src="assets/images/project-7.jpg" alt="" class=" img-responsive">
											<a href="assets/images/project-7.jpg" class="image-link">
												<div class="temp_overlay">
													<div class="overlay_detail">
														<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="30px" height="30px" viewBox="0 0 485.213 485.213">
															<g>
																<path d="M471.882,407.567L360.567,296.243c-16.586,25.795-38.536,47.734-64.331,64.321l111.324,111.324
																c17.772,17.768,46.587,17.768,64.321,0C489.654,454.149,489.654,425.334,471.882,407.567z"/>
																<path d="M363.909,181.955C363.909,81.473,282.44,0,181.956,0C81.474,0,0.001,81.473,0.001,181.955s81.473,181.951,181.955,181.951
																C282.44,363.906,363.909,282.437,363.909,181.955z M181.956,318.416c-75.252,0-136.465-61.208-136.465-136.46
																c0-75.252,61.213-136.465,136.465-136.465c75.25,0,136.468,61.213,136.468,136.465
																C318.424,257.208,257.206,318.416,181.956,318.416z"/>
																<path d="M75.817,181.955h30.322c0-41.803,34.014-75.814,75.816-75.814V75.816C123.438,75.816,75.817,123.437,75.817,181.955z"/>
															</g>
														</svg></span>
													</div>
												</div>
											</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<svg class="svg_border" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
				</div>

				<!--section7 start-->


				<!--section6 start-->
				<div class="temp_testimonial_wrapper">
					<div class="container">
						<div class="row">
							<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0 text-center ">
								<div class="heading_wrapper wow rubberBand" data-wow-duration="2.5s">
									<h3 class="heading">Our Happy Clients</h3>
									<div class="clearfix"></div>
									<div class="right bottompadder10">
										<img src="assets/images/heading_icon.png" alt="" width="205" height="32">
									</div>
								</div>
							</div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<center><a href="https://www.google.com/search?client=firefox-b-d&q=%28762%29+218-5701+#lrd=0x42580847961ec9c1:0x6fedc5b9e58ad35,1,,,," target="_blank"><img src="assets/images/google-reviews.jpg"></a></center>
								<div class="testimonial_slider_wrapper wow fadeIn">
									<div class="swiper-container">
										<div class="swiper-wrapper">
											<div class="swiper-slide">
												<div class="testimonial_slider">
													<div class="testimonial_slider_flex">
														<div class="bottompadder10">
															<p class="subheading"><a href="#">Cheryl C</a></p>
														</div>
													</div>
													<p class="paragraph">A team did an outstanding job painting the inside of our home. They give close attention to detail. We are so pleased with the results. Our home looks new again. Highly recommend.</p>
												</div>
											</div>
											<div class="swiper-slide">
												<div class="testimonial_slider">
													<div class="testimonial_slider_flex">
														<div class="bottompadder10">
															<p class="subheading"><a href="#">Tracy F</a></p>
														</div>
													</div>
													<p class="paragraph">I needed my place pressure washed. Outstanding job! My decks look brand new! Thank you Bobby and Eddie for taking care of me!</p>
												</div>
											</div>
											<div class="swiper-slide">
												<div class="testimonial_slider">
													<div class="testimonial_slider_flex">
														<div class="bottompadder10">
															<p class="subheading"><a href="#">Addy Maye</a></p>
														</div>
													</div>
													<p class="paragraph">Very professional. On time. Very responsive and talks through the process when it comes to pricing, and his work. Highly recommend.</p>
												</div>
											</div>
											<div class="swiper-slide">
												<div class="testimonial_slider">
													<div class="testimonial_slider_flex">
														<div class="bottompadder10">
															<p class="subheading"><a href="#">Lynn Neal</a></p>
														</div>
													</div>
													<p class="paragraph">I've had the great pleasure of working for the company and I enjoyed the time together with the team and crew members! Very professional, dedicated and the attention to detail is 2nd to none! Outstanding company that I would definitely call for you and your family and friends for all your home care needs!</p>
												</div>
											</div>
										</div>
										<div class="swiper-pagination"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--section6 end-->


				<!--section9 start-->	
				<?php include("includes/footer.php");?>
			

			</body>
			</html>