<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>A-Team Painting & Home Care, LLC | Painting Contractor</title>
	<meta name="description" content="" />
	<meta name="keywords" content="">

	<?php include("includes/header-files.php");?>
	
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="heading">Testimonials A-Team Painting & Home Care, LLC</h1>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">Testimonials</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->

<!--section3 start-->
<div class="temp_about_wrapper wow slideInUp" data-wow-duration="1.5s">
<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			 <!-- About Section -->
    <section class="about-section style-two">
        <div class="auto-container">
            <div class="row">
                <div class="col-lg-8">


            <div class="test-id">
              <h3>Cheryl C</h3>
              <ul>
                <li>
                  <i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>                        
                </ul>
                <p>A team did an outstanding job painting the inside of our home. They give close attention to detail. We are so pleased with the results. Our home looks new again. Highly recommend.</p>
              </div>

              <div class="test-id">
              <h3>Tracy F</h3>
              <ul>
                <li>
                  <i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>                        
                </ul>
                <p>I needed my place pressure washed. Outstanding job! My decks look brand new! Thank you Bobby and Eddie for taking care of me!</p>
              </div>

              <div class="test-id">
              <h3>Addy Maye</h3>
              <ul>
                <li>
                  <i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>                        
                </ul>
                <p>Very professional. On time. Very responsive and talks through the process when it comes to pricing, and his work. Highly recommend.</p>
              </div>

              <div class="test-id">
              <h3>Lynn Neal</h3>
              <ul>
                <li>
                  <i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>                        
                </ul>
                <p>I've had the great pleasure of working for the company and I enjoyed the time together with the team and crew members! Very professional, dedicated and the attention to detail is 2nd to none! Outstanding company that I would definitely call for you and your family and friends for all your home care needs!</p>
              </div>

              <div class="test-id">
              <h3>Dwight Neal</h3>
              <ul>
                <li>
                  <i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>
                  <li><i class="fa fa-star orange"></i></li>                        
                </ul>
                <p>I worked with Bobby at Augusta National for a few years and can tell you first hand that his attention to detail is second to none! So when I bought my house it was a no brainer to let him paint it! His team gave me an excellent paint job as expected and and even gave me a discount for referring my neighbors to him.</p>
              </div>
              


            </div>
                <!-- Image column -->
                <div class="col-md-4">
              <div class="text-form">
                <h4>Reviews</h4>
                <form method="post" id="reviews">
                    <input type="hidden" id="g-token" name="g-token"/>
                  <div class="form-field1" >
                    <span>Rating</span>
                    <ul>
                      <li >
                          
                        <label>
                          <input type="checkbox" name="rating"    id="rating_1" value="1">
                          <i class="fa fa-star"></i>
                        </label>
                      </li>
                      <li>
                        <label>
                          <input type="checkbox"  name ="rating" id="rating_2" value="2">
                          <i class="fa fa-star"></i>
                        </label>
                      </li>
                      <li>
                        <label>
                          <input type="checkbox" name="rating"  id="rating_3" value="3">
                          <i class="fa fa-star"></i>
                        </label>
                      </li>
                      <li>
                        <label>
                          <input type="checkbox" name="rating"  id="rating_4" value="4">
                          <i class="fa fa-star"></i>
                        </label>
                      </li>
                      <li>
                        <label>
                          <input type="checkbox" name="rating" id="rating_5" value="5">
                          <i class="fa fa-star"></i>
                        </label> 
                        
                      </li>
                    </ul>
                    <!--<input type="hidden" name="rating" >-->
                  </div>
                  <div class="form-field1">
                    <input type="text" name="name" required="" placeholder="Name">
                  </div>

                  <div class="form-field1">
                    <input type="email" name="email" placeholder="Email">
                  </div>

                  <div class="form-field1">
                    <textarea name="description" required="" placeholder="Comments"></textarea>
                  </div>

                  <div class="form-field1">
                    <button type="submit" name="btn_submit">Submit</button>
                  </div>
                </form>
              </div>
            </div>
            </div>
        </div>
    </section>
    <!--End About Section -->

    <script type="text/javascript">
        $('#reviews').on('submit', function () {
          var checkboxes = document.querySelectorAll('input[type="checkbox"]');
          var checkedOne = Array.prototype.slice.call(checkboxes).some(x => x.checked);
          if (checkedOne == true)
          {
            return true;
          } else {
            alert('Please select Rating!');
            return false;
          }
        });

        $(document).ready(function(){
          $("#rating_1").click(function(){
            $("#rating_1").prop("checked", true);
            $("#rating_2").prop("checked", false);
            $("#rating_3").prop("checked", false);
            $("#rating_4").prop("checked", false);
            $("#rating_5").prop("checked", false);
            var rating = $("#rating_1").val();
            $('#rating').val(rating);

          });
          $("#rating_2").click(function(){
            $("#rating_1").prop("checked", true);
            $("#rating_2").prop("checked", true);
            $("#rating_3").prop("checked", false);
            $("#rating_4").prop("checked", false);
            $("#rating_5").prop("checked", false);
            var rating = $("#rating_2").val();
            $('#rating').val(rating);
          });
          $("#rating_3").click(function(){
            $("#rating_1").prop("checked", true);
            $("#rating_2").prop("checked", true);
            $("#rating_3").prop("checked", true);
            $("#rating_4").prop("checked", false);
            $("#rating_5").prop("checked", false);
            var rating = $("#rating_3").val();
            $('#rating').val(rating);
          });
          $("#rating_4").click(function(){
            $("#rating_1").prop("checked", true);
            $("#rating_2").prop("checked", true);
            $("#rating_3").prop("checked", true);
            $("#rating_4").prop("checked", true);
            $("#rating_5").prop("checked", false);
            var rating = $("#rating_4").val();
            $('#rating').val(rating);
          });
          $("#rating_5").click(function(){
            $("#rating_1").prop("checked", true);
            $("#rating_2").prop("checked", true);
            $("#rating_3").prop("checked", true);
            $("#rating_4").prop("checked", true);
            $("#rating_5").prop("checked", true);
            var rating = $("#rating_5").val();
            $('#rating').val(rating);
          });

        });
      </script>
		</div>
	</div>
</div>
<!--section3 end-->



<!--section5 start-->	
<?php include("includes/footer.php");?>
</body>
</html>