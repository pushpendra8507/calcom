<?php 
 include("classes/startup.php");
 $core = new Core;
 $mv_blog = new MV_Blog;


 if(!isset($_REQUEST['alias']) || empty($_REQUEST['alias'])){
    header('location:index.php');
    exit;
 }

?>

<!DOCTYPE html>
<html lang="en">
      <?php $blogs_seo = $mv_blog->get_details_by_alias($_REQUEST['alias']); ?>
     <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title><?php echo isset($blogs_seo['seo_title'])? $blogs_seo['seo_title']: '' ?></title>
	<meta name="description" content="<?php echo isset($blogs_seo['seo_description'])? $blogs_seo['seo_description']: '' ?>" />
	<meta name="keywords" content="<?php echo isset($blogs_seo['seo_keyword'])? $blogs_seo['seo_keyword']: '' ?>">
	<?php include("includes/header-files.php");?>
	
</head>
<body>
<!--section1 start-->	
<?php include("includes/header.php");?>

<!--section2 start-->
<div class="temp_inner_banner wow fadeIn">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<h1 class="d-none"><?php echo isset($blogs_seo['seo_h1'])? $blogs_seo['seo_h1']: '' ?></h1>
				<h2 class="d-none"><?php echo isset($blogs_seo['seo_h2'])? $blogs_seo['seo_h2']: '' ?></h2>
				<h3 class="heading">Blog Details</h3>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="./" class="paragraph">Home</a></li>
					<li class="breadcrumb-item active"><span class="paragraph">Blog Details</span></li>
				</ol>
			</div>
		</div>
	</div>
</div>
<!--section2 end-->
<?php $blogs_data = $mv_blog->get_details_by_alias($_REQUEST['alias']); ?>
<!--section3 start-->
<div class="temp_blog_single_wrapper">
<svg class="svg_border2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none" height="50" width="100%"> <path class="exqute-fill-white" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3 c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3 c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
				<div class="blog_single wow fadeInUp" data-wow-duration="1.5s">
					<div class="text-center">
						<div class="temp_hover">
							<img src="<?php echo isset($blogs_data['photourl'])? $blogs_data['photourl']: '' ?>" alt="<?php echo isset($blogs_data['alt_name'])? $blogs_data['alt_name']: '' ?>" class=" img-responsive">
							<div class="blog_single_overlay"></div>
						</div>
						<div class="blog_detail text-left">
							<h3 class="subheading"><a href="<?php echo isset($blogs_data['alias'])? $blogs_data['alias']: '' ?>"><?php echo isset($blogs_data['title'])? $blogs_data['title']: '' ?></a></h3>
							<p><?php echo isset($blogs_data['description'])? $blogs_data['description']: '' ?></p>

							<!-- <p><?php echo isset($blogs_data['tags'])? $blogs_data['tags']: '' ?> </p> -->
						</div>
					</div>

					<!-- ShareThis BEGIN --><div class="sharethis-inline-share-buttons"></div><!-- ShareThis END -->

					<div class="comment-respond text-elft wow fadeIn">
						<h1 class="comment-reply-title padder_bottom30">leave a comment</h1>
						<form>
							<div class="form-group">
								<input type="text" class="form-control required" id="name" placeholder="Enter Your Name">
							</div>
							<div class="form-group">
								<input type="email" class="form-control required" id="email" placeholder="Enter Your Email">
							</div>
							<div class="form-group message">
								<textarea class="form-control required" id="message" rows="3" placeholder="Message"></textarea>
							</div>
							<button type="submit" class="btn temp_btn">Submit</button>
						</form>
					</div>
				</div>
			</div>
			<?php include("includes/blog-sidebar.php");?>
		</div>
	</div>
</div>
<!--section3 end-->



<!--section5 start-->	
<?php include("includes/footer.php");?>
</body>
</html>