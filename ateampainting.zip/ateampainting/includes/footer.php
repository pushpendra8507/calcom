<div class="temp_footer_wrapper">
<svg class="svg_border1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" 	preserveAspectRatio="none" height="50" width="100%"> <path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
 c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
 c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path> </svg>
	<div class="container">
		<div class="row">
			<div class="temp_footer_Section">
				<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
					<div class="footer_section  bottompadder60 ">
						<p class="subheading">Your Top Local Painting Contractors</p>
						<div class="footer_flex bottompadder20">
							<div class="footer_right">
								<a href="#">Get in Touch Today</a>
								<p>When you choose A-Team Painting & Home Care, LLC, you’re choosing quality, integrity, and reliability. You’re choosing prompt, professional painters who don’t cut corners. You’re choosing the best painting contractors around.</p>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
					<div class="footer_section sec4 bottompadder60 ">
						<p class="subheading ">Contact Information</p>
						<ul>	
							<li><span><i class="fa fa-map-marker" aria-hidden="true"></i></span><span><a href="https://goo.gl/maps/6cSVmJQSnQpmdhKj9" target="_blank">Blythe, GA 30805-3536</a></span></li>
							<li><span><i class="fa fa-phone" aria-hidden="true"></i></span><span><a href="tel:7622185701">(762) 218-5701</a>, <a href="tel:7063730056">(706) 373-0056</a></span></li>
							<li><a href="mailto:info@ateampainting.us"><span><i class="fa fa-envelope" aria-hidden="true"></i></span><span>info@ateampainting.us</span></a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
					<div class="footer_section sec4 bottompadder60 ">
						<p class="subheading ">Business Hours</p>
						<ul>	
							<li><span><i class="fa fa-clock-o" aria-hidden="true"></i></span><span>Mon - Fri: 8:00AM - 5:00PM</span></li>
							<li><span><i class="fa fa-clock-o" aria-hidden="true"></i></span><span>Sat: 9:00AM - 2:00PM</span></li>
							<li><span><i class="fa fa-clock-o" aria-hidden="true"></i></span><span>Sun: Closed</span></li>
							<li><span><strong>Emergency Service Available</strong></span></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="temp_copyright text-center">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<p class="paragraph">&copy; 2023 A-Team Painting & Home Care, LLC. All Rights Reserved.<br>
						<a href="https://www.wxperts.co/website-development.php" target="_blank">Website Development</a> | <a href="https://www.wxperts.co/" target="_blank">Hosting</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Digital Marketing</a>
						<br><a href="https://www.wxperts.co/" target="_blank"><img src="assets/images/wxperts_powerdby.jpg" alt="webxperts"></a></p>
				</div>
			</div>
		</div>
	</div>
</div>
<!--section10 end-->
<?php include("includes/get-free-estimate.php");?>
<!--theme js-->
<script type="text/javascript">!function(){ var b=function(){ window.__AudioEyeSiteHash = "c12de685df79909121bb2025cff8d85b"; var a=document.createElement("script"); a.src="https://wsmcdn.audioeye.com/aem.js"; a.type="text/javascript"; a.setAttribute("async",""); document.getElementsByTagName("body")[0].appendChild(a)}; "complete"!==document.readyState?window.addEventListener?window.addEventListener("load",b):window.attachEvent&&window.attachEvent("onload",b):b()}(); </script><link rel='stylesheet' id='datetimecss-css'  href='https://ateampainting.us/wp-content/plugins/linknowmedia-email//styles/jquery.datetimepicker.css' media='all' />
	
	<script src="assets/js/jquery.js"></script>
	<script src="assets/js/wow.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/jQuery.scrollSpeed.js"></script>
	<script src="assets/js/swiper.min.js"></script>
	<script src="assets/js/jquery.magnific-popup.min.js"></script>
	<script src="assets/js/custom.js"></script>

