<?php $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>
    <meta name="author" content="<?php echo isset($url)?$url:'' ?>"/>
    <meta name="robots" content="index, follow"/>
    <meta name="rating" content="safe for kids"/>
    <meta name="googlebot" content=" index, follow"/>
    <meta name="allow-search" content="yes"/>
    <meta name="revisit-after" content="daily"/>
    <meta name="language" content="en-US"/>
    <meta name="distribution" content="global"/>
    <link rel="canonical" href="<?php echo isset($url)?$url:'' ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <link rel="icon" type="image/ico" href="assets/images/favicon.png">
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/custom_animation.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/fonts.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/main.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/swiper.min.css"/>
    <link rel="stylesheet" type="text/css" href="assets/css/style.css"/>

    <?php
 include("classes/startup.php");
 $core = new Core;

 $mv_blog = new MV_Blog;



 $all_projects = $mv_blog->index_limit();

?>