<?php
include('classes/startup.php');
$core = new Core;
$all_projects = $mv_blog->index_limit();
?>

<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=647fa46cf4011b00122d3f89&product=inline-share-buttons' async='async'></script>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
	<div class="temp_sidebar">

		<div class="widget widget_resentpost padder_bottom50 wow fadeInRight" data-wow-duration="1.5s" data-wow-delay="0.3s">
			<h2 class="widget-title">recent post</h2>
			<?php foreach ($all_projects as $blog_service) { ?>
				<div class="post_slider">
					<div class="rp_img">
						<img src="<?php echo isset($blog_service['photourl']) ? $blog_service['photourl'] : '' ?>" alt="" class="img-responsive">
						<a href="<?php echo isset($blog_service['alias']) ? $blog_service['alias'] : '' ?>"><?php echo isset($blog_service['date']) ? $blog_service['date'] : '' ?></a>
					</div>
					<div class="rp_content">
						<a href="<?php echo isset($blog_service['alias']) ? $blog_service['alias'] : '' ?>"><?php echo isset($blog_service['title']) ? $blog_service['title'] : '' ?></a>
					</div>
				</div>
			<?php } ?>
		</div>

	</div>
</div>