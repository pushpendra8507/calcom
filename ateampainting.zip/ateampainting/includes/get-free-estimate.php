<?php
include_once 'ContactFunctions.php';

if(isset($_POST) && isset($_POST["btn_submit"]))
{
	if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
		echo '<script>window.location="./"</script>'; exit;
	}

	$name = $email = $phone = $service =  $address = "";
	if($_SERVER["REQUEST_METHOD"] == "POST")
	{

		$secretKey='6LdLEzAnAAAAALTAWG_B0wDKS3T8ggvrLStIzKU-';
		$token    = $_POST["g-token"];
		$ip     = $_SERVER['REMOTE_ADDR'];

		if(empty($_POST["name"]))
		{
			echo '<script>window.location="./"</script>'; exit;
		} 
		else
		{
			$name = filterName($_POST["name"]);
			if($name == FALSE){
				echo '<script>window.location="./"</script>'; exit;
			}
		}

		if(empty($_POST["email"]))
		{
			echo '<script>window.location="./"</script>'; exit;    
		} 
		else
		{
			$email = filterEmail($_POST["email"]);
			if($email == FALSE){
				echo '<script>window.location="./"</script>'; exit;
			}
		}

		$phone = (isset($_POST["phone"]) && !empty($_POST["phone"]))? $_POST["phone"]: '';
		$service = (isset($_POST["service"]) && !empty($_POST["service"]))? $_POST["service"]: '';
		$address = (isset($_POST["address"]) && !empty($_POST["address"]))? $_POST["address"]: '';

        // Validate user message
        // if(empty($_POST["description"]))
        // {
        //     echo '<script>window.location="./"</script>'; exit;    
        // } 
        // else
        // {
        //     $msge = filterString($_POST["description"]);
        //     if($msge == FALSE){
        //         echo '<script>window.location="./"</script>'; exit;
        //     }
        // }

		$url = "https://www.google.com/recaptcha/api/siteverify";
		$data = array('secret' => $secretKey, 'response' => $token, 'remoteip'=> $ip);

          // use key 'http' even if you send the request to https://...
		$options = array('http' => array(
			'method'  => 'POST',
			'content' => http_build_query($data)
		));
		$context  = stream_context_create($options);
		$result = file_get_contents($url, false, $context);
		$response = json_decode($result);
        //echo '<pre>';print_r($response);die();
		if($response->success)
		{
			define('BUSINESS_NAME','A-Team Painting & Home Care');
			define('FORM_TYPE','Get Free Estimate');
			$to = 'bbbythigpen@gmail.com';
            // $to = 'ravi02.agp@gmail.com';
            // $to ='pushpendra639263@gmail.com';
			$fromMail='no-reply@ateampaintingandhomecarellc.com';
			$fromName = BUSINESS_NAME;
			$subject = BUSINESS_NAME.' - '.FORM_TYPE;
			$message = '<html><head><title>'.BUSINESS_NAME.'</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
			<table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

			<tr>
			<td height="25"  colspan="2"><center><strong>'.BUSINESS_NAME.'</strong></center></td>
			</tr>
			</table>
			<table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
			<tbody>
			<tr>
			<td width="100%" valign="top">
			<table width="100%" cellspacing="3" cellpadding="5" border="1" >
			<tbody>     
			<tr>
			<td colspan="2"><center><strong>'.FORM_TYPE.'</strong></center></td>
			</tr>
			<tr>
			<td width="30%">Name:</td>
			<td width="70%">' . $name . '</td>
			</tr>
			<tr>
			<td>Email:</td>
			<td>' . $email . '</td>
			</tr>

			<tr>
			<td>Phone:</td>
			<td>' . $phone . '</td>
			</tr>
			<tr>
			<td>Service:</td>
			<td>'. $service . '</td>
			</tr>
			<tr>
			<td>Address:</td>
			<td>'. $address . '</td>
			</tr>


			</tbody>
			</table>
			</td>
			</tr>
			</tbody>
			</table>
			</div></body></html>';
                // To send HTML mail, the Content-type header must be set
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
			$headers .= 'From:'.$fromName." ".'<'.$fromMail.'>'."\r\n";
			$headers .= 'Bcc: wxperts.co@gmail.com,wxperts.co@outlook.com,contact@wxperts.co' . "\r\n";
			$message = str_replace("\'", "'", $message);
                //echo $message;exit;
			$send_mail = mail($to, $subject, $message, $headers);

			if($send_mail)
			{
				echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
			}
			else 
			{
				echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
			}
		}
		else
		{
			echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
		}
	}
}

?>
	<script src="https://www.google.com/recaptcha/api.js?render=6LdLEzAnAAAAAFxwTADT63ykZKQw2GLH2lNMGKu1"></script>
	
		<script>
					grecaptcha.ready(function() {
						grecaptcha.execute('6LdLEzAnAAAAAFxwTADT63ykZKQw2GLH2lNMGKu1', {action: 'homepage'}).then(function(token) {

							document.getElementById("g-token").value = token;
						});
					});
				</script>
<!--Modal -->
	<div class="modal fade" id="temp_exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					<h5 class="modal-title" id="exampleModalLabel">Get Free Estimate</h5>
				</div>
				<div class="modal-body">
					<form method ="post">
						<input type="hidden" id="g-token" name="g-token"/>
						<div class="form-group">
							<label>Name</label>
							<input type="text" name="name" placeholder="type your name..." required>
						</div>
						<div class="form-group">
							<label>Phone</label>
							<input type="text" name="phone" placeholder="type your contact no..." required>
						</div>
						<div class="form-group">
							<label>Email</label>
							<input type="email" name="email" placeholder="type your email..." required>
						</div>
						<div class="form-group">
							<label>Service</label>
							<input type="text" name="service" placeholder="type your service..." required>
						</div>
						<div class="form-group">
							<label>Address</label>
							<textarea name="address" placeholder="type your address..." required></textarea>
						</div>

					</div>
					<div class="modal-footer">
						<button  name ="btn_submit">Submit</button>
					</div>
				</div>
			</form>
		</div>
	</div>
	
	<!--Modal -->